{
    "patcher": {
        "fileversion": 1,
        "appversion": {
            "major": 9,
            "minor": 1,
            "revision": 5,
            "architecture": "x64",
            "modernui": 1
        },
        "classnamespace": "box",
        "rect": [ 134.0, 92.0, 1100.0, 1074.0 ],
        "boxes": [
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "title",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 15.0, 1050.0, 20.0 ],
                    "text": "SuperVP für Live-Elektronik"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "intro",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 52.0, 1050.0, 20.0 ],
                    "text": "Mono-Beispiel für Audioeingang 1. Alle Objekte sind sichtbar und ungruppiert. Jede Steuerung sendet über s #0-supervp zum einzigen Empfänger unten."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "head-a",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 105.0, 320.0, 20.0 ],
                    "text": "1 · TONHÖHE UND ARBEITSBEREICH"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "head-b",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 105.0, 320.0, 20.0 ],
                    "text": "2 · KLANGCHARAKTER"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "head-c",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 105.0, 320.0, 20.0 ],
                    "text": "3 · FENSTER UND RECHENAUFWAND"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pitch-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 145.0, 315.0, 20.0 ],
                    "text": "Transposition in Cent"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "format": 6,
                    "id": "pitch",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "bang" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 25.0, 174.0, 95.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pitch-cmd",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 135.0, 174.0, 180.0, 22.0 ],
                    "text": "transpose $1"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pitch-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 225.0, 205.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pitch-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 25.0, 126.0, 170.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pitch-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 235.0, 274.0, 33.0 ],
                    "text": "100 Cent = Halbton · 1200 Cent = Oktave.\n0 = Originaltonhöhe. Keine feste Feldbegrenzung."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pres-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 145.0, 315.0, 20.0 ],
                    "text": "Klangcharakter beim Transponieren erhalten"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pres",
                    "items": [ "envpres", "off", ",", "envpres", "on" ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "int", "", "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 385.0, 174.0, 190.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pres-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 385.0, 205.0, 105.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pres-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 500.0, 205.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "pres-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 235.0, 307.0, 33.0 ],
                    "text": "envpres on versucht die spektrale Hüllkurve zu erhalten.\nZum Vergleich bei gleicher Transposition umschalten."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-on-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 300.0, 315.0, 20.0 ],
                    "text": "Option: Hüllkurve separat verschieben"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-on",
                    "items": [ "envtrans", "off", ",", "envtrans", "on" ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "int", "", "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 385.0, 329.0, 190.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-on-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 385.0, 360.0, 105.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-on-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 595.0, 329.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-on-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 390.0, 262.0, 33.0 ],
                    "text": "Zum reinen Pitch-Vergleich zunächst off lassen.\nDie Einstellung darunter ist nur bei on relevant."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 455.0, 315.0, 20.0 ],
                    "text": "Hüllkurven-Verschiebung in Cent"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "format": 6,
                    "id": "env",
                    "maxclass": "flonum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "bang" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 385.0, 484.0, 95.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-cmd",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 495.0, 484.0, 180.0, 22.0 ],
                    "text": "envtrans $1"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 585.0, 515.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 385.0, 515.0, 170.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "env-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 545.0, 260.0, 33.0 ],
                    "text": "Verändert Resonanzbereiche und Klangfarbe.\n0 = keine zusätzliche Hüllkurven-Verschiebung."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "transients-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 610.0, 315.0, 20.0 ],
                    "text": "Transienten / Anschläge erhalten"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "transients",
                    "items": [ "transients", "off", ",", "transients", "on" ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "int", "", "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 385.0, 639.0, 190.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "transients-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 385.0, 670.0, 105.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "transients-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 595.0, 639.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "transients-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 385.0, 700.0, 285.0, 33.0 ],
                    "text": "Kann die Behandlung kurzer Anschläge verbessern.\nUmschalten kann die Engine neu initialisieren."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "window-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 145.0, 315.0, 20.0 ],
                    "text": "Fenstergröße in Samples"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "window",
                    "items": [ "512", ",", "1024", ",", "2048", ",", "4096", ",", "8192" ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "int", "", "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 745.0, 174.0, 190.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "window-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 745.0, 205.0, 105.0, 22.0 ],
                    "text": "loadmess set 2"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "window-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 955.0, 174.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "window-prefix",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 855.0, 205.0, 180.0, 22.0 ],
                    "text": "prepend windowsize"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "window-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 235.0, 284.0, 33.0 ],
                    "text": "Kleiner: meist kürzere Verzögerung. Größer: feinere\nFrequenzauflösung; beeinflusst Klang und Latenz."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "over-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 300.0, 315.0, 20.0 ],
                    "text": "Zeitliche Überlappung"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "over",
                    "maxclass": "number",
                    "minimum": 1,
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "", "bang" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 745.0, 329.0, 95.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "over-cmd",
                    "maxclass": "message",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 855.0, 329.0, 180.0, 22.0 ],
                    "text": "oversamp $1"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "over-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 945.0, 360.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "over-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 745.0, 360.0, 170.0, 22.0 ],
                    "text": "loadmess set 4"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "over-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 390.0, 311.0, 33.0 ],
                    "text": "Hop-Abstand = Fenstergröße / oversamp.\nHöher bedeutet mehr Überlappung und Rechenaufwand."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "fft-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 455.0, 315.0, 20.0 ],
                    "text": "Zusätzliche FFT-Vergrößerung"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "fft",
                    "items": [ "0", ",", "1", ",", "2" ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "int", "", "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 745.0, 484.0, 190.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "fft-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 745.0, 515.0, 105.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "fft-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 955.0, 484.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "fft-prefix",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 855.0, 515.0, 180.0, 22.0 ],
                    "text": "prepend fftover"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "fft-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 545.0, 294.0, 33.0 ],
                    "text": "FFT-Größe = Fenstergröße × 2 hoch fftover.\n0 = normale FFT-Größe. Erhöht den Rechenaufwand."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "shape-label",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 610.0, 315.0, 20.0 ],
                    "text": "Alternative: Wellenform erhalten"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "shape",
                    "items": [ "shapeinv", "off", ",", "shapeinv", "on" ],
                    "maxclass": "umenu",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [ "int", "", "" ],
                    "parameter_enable": 0,
                    "patching_rect": [ 745.0, 639.0, 190.0, 22.0 ]
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "shape-init",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [ "" ],
                    "patching_rect": [ 745.0, 670.0, 105.0, 22.0 ],
                    "text": "loadmess set 0"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "shape-send",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 955.0, 639.0, 100.0, 22.0 ],
                    "text": "s #0-supervp"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "shape-desc",
                    "linecount": 2,
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 745.0, 700.0, 245.0, 33.0 ],
                    "text": "shapeinv hat Vorrang vor transients. Für den\nTransienten-Vergleich shapeinv off lassen."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "setup-note",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 770.0, 1040.0, 20.0 ],
                    "text": "Fenster- und Verfahrenswechsel können die Engine neu starten und klicken. Diese Einstellungen am besten zwischen Hörvergleichen ändern."
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "audio-head",
                    "maxclass": "comment",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "patching_rect": [ 25.0, 825.0, 1040.0, 20.0 ],
                    "text": "4 · AUDIOWEG — Eingang 1 → SuperVP → Ausgang 1/2"
                }
            },
            {
                "box": {
                    "fontname": "Arial",
                    "fontsize": 12.0,
                    "id": "engine",
                    "maxclass": "newobj",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [ "signal", "" ],
                    "patching_rect": [ 265.0, 875.0, 339.0, 22.0 ],
                    "text": "supervp.trans~ 1 2048 0 4 @mintrans -6000 @maxtrans 6000"
                }
            }
        ],
        "lines": [
            {
                "patchline": {
                    "destination": [ "env-cmd", 0 ],
                    "source": [ "env", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "env-send", 0 ],
                    "source": [ "env-cmd", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "env", 0 ],
                    "source": [ "env-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "env-on-send", 0 ],
                    "source": [ "env-on", 1 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "env-on", 0 ],
                    "source": [ "env-on-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "fft-prefix", 0 ],
                    "source": [ "fft", 1 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "fft", 0 ],
                    "source": [ "fft-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "fft-send", 0 ],
                    "source": [ "fft-prefix", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "over-cmd", 0 ],
                    "source": [ "over", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "over-send", 0 ],
                    "source": [ "over-cmd", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "over", 0 ],
                    "source": [ "over-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "pitch-cmd", 0 ],
                    "source": [ "pitch", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "pitch-send", 0 ],
                    "source": [ "pitch-cmd", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "pitch", 0 ],
                    "source": [ "pitch-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "pres-send", 0 ],
                    "source": [ "pres", 1 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "pres", 0 ],
                    "source": [ "pres-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "shape-send", 0 ],
                    "source": [ "shape", 1 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "shape", 0 ],
                    "source": [ "shape-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "transients-send", 0 ],
                    "source": [ "transients", 1 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "transients", 0 ],
                    "source": [ "transients-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "window-prefix", 0 ],
                    "source": [ "window", 1 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "window", 0 ],
                    "source": [ "window-init", 0 ]
                }
            },
            {
                "patchline": {
                    "destination": [ "window-send", 0 ],
                    "source": [ "window-prefix", 0 ]
                }
            }
        ],
        "autosave": 0
    }
}