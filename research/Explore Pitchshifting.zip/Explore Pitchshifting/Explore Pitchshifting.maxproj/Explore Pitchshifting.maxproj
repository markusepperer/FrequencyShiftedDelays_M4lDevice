{
    "name": "Explore Pitchshiftimg.maxproj",
    "version": 1,
    "creationdate": 3875692239,
    "modificationdate": 3875692239,
    "viewrect": [ 0.0, 0.0, 300.0, 500.0 ],
    "autoorganize": 1,
    "hideprojectwindow": 0,
    "showdependencies": 1,
    "autolocalize": 0,
    "contents": {
        "patchers": {
            "Explore Pitchshiftimg.maxproj.maxpat": {
                "kind": "patcher",
                "local": 1,
                "toplevel": 1
            }
        },
        "code": {        }
    },
    "layout": {    },
    "searchpath": {    },
    "detailsvisible": 0,
    "amxdtype": 0,
    "readonly": 0,
    "devpathtype": 0,
    "devpath": ".",
    "sortmode": 0,
    "viewmode": 0,
    "includepackages": 0
}