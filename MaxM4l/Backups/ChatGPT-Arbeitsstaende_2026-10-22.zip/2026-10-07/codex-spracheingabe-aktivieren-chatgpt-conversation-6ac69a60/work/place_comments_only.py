from pathlib import Path
import json,copy,struct,datetime,sys
P=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/Freqshiftdelays_m4l.amxd');raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d);q=next(z['box']['patcher'] for z in d['patcher']['boxes'] if z['box']['id']=='obj-4');b={z['box']['id']:z['box'] for z in q['boxes']}
placements={
 'timefade-ready':('Nach Live-Initialisierung: gespeicherte Fade-Dauer abfragen.',[1008.,-164.6,480.,18.],10.),
 'timefade-defer':('Abfrage zurückstellen; danach aktuellen Numberbox-Wert ausgeben.',[1008.,-143.1,490.,18.],10.),
 'timechange-fade':('Fade-Dauer in Sekunden (0,1–10 s); gespeichert und automatisierbar.',[1008.,-95.,490.,18.],10.),
 'timefade-ms':('× 1000: Sekunden → Millisekunden.',[1000.,-64.6,230.,18.],10.),
 'timefade-store':('Rechts Dauer merken; links beim Fade-Beginn abrufen.',[920.,-36.9,325.,18.],10.),
 'timefade-values':('Rechts Timerdauer setzen; links Matrix-Rampe setzen.',[905.,-3.1,330.,18.],10.),
 'timefade-protect100':('100 ms: kurzer Schutzfade.',[580.,-9.2,150.,18.],9.),
 'timefade-ramp':('„ramp <ms>“: Überblendungsdauer der vier Ausgangsmatrizen.',[875.,44.6,400.,18.],10.),
 'obj-39':('Steuerbus für vier Matrizen.',[920.,89.,170.,16.],10.),
 'timefade-protect':('Rechts: 100 ms setzen.\nLinks: Schatten auswählen.',[464.,-112.,160.,28.],9.),
 'obj-113':('Start: zuerst Schatten,\ndanach 100 ms warten.',[120.,-119.,185.,28.],10.),
 'timefade-return':('Rechts: Dauer. Mitte: Hauptbank.\nLinks: Schatten-Timer starten.',[477.,44.6,245.,28.],10.),
 'obj-556':('Nach Fade-Ende: Schattenzeiten nachführen.\nTimerdauer = gewählte Fade-Dauer.',[410.,214.,330.,26.],10.),
 'midi-trigger-reset-order':('Button nach 50 ms zurücksetzen.\nNoch keine Sperre über den ganzen Fade.',[670.,-284.,320.,28.],10.),
}
for i,id in enumerate(['obj-132','obj-131','obj-122','obj-44'],1):
 x,y,w,h=b[id]['patching_rect'];placements[id]=(f'D{i}: Fade-Zeit',[x+w+8.,y,105.,18.],9.)
for anchor,(text,rect,font) in placements.items():
 note=b['timefade-doc-'+anchor];assert note['maxclass']=='comment'
 note.update(text=text,patching_rect=rect,fontsize=font,linecount=len(text.splitlines()))
# Reject changes to any non-comment object, all patchcords, any parameter, and the presentation interface.
def without_comments(q):
 q=copy.deepcopy(q);q['boxes']=[z for z in q['boxes'] if z['box']['maxclass']!='comment']
 for z in q['boxes']:
  if 'patcher'in z['box']:z['box']['patcher']=without_comments(z['box']['patcher'])
 return q
assert without_comments(d['patcher'])==without_comments(old['patcher'])
oq=next(z['box']['patcher'] for z in old['patcher']['boxes'] if z['box']['id']=='obj-4');oldbs={z['box']['id']:z['box'] for z in oq['boxes']}
for id,obj in oldbs.items():
 if not id.startswith('timefade-doc-'):assert b[id]==obj
 else:assert b[id].get('presentation_rect')==obj.get('presentation_rect')
# Confirm the new explanatory boxes overlap neither existing objects nor each other.
def overlap(a,c):return a[0]<c[0]+c[2] and a[0]+a[2]>c[0] and a[1]<c[1]+c[3] and a[1]+a[3]>c[1]
notes=[b['timefade-doc-'+id] for id in placements]
for note in notes:
 for id,obj in b.items():
  if id==note['id'] or id.startswith('timefade-doc-'):continue
  assert not overlap(note['patching_rect'],obj['patching_rect']),(note['id'],id)
for i,a in enumerate(notes):
 for c in notes[i+1:]:assert not overlap(a['patching_rect'],c['patching_rect']),(a['id'],c['id'])
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';h=bytearray(raw[:32]);h[28:32]=struct.pack('<I',len(payload));new=bytes(h)+payload;assert json.JSONDecoder().raw_decode(new[32:].decode())[0]==d
Path('work/comments_only.prepared.amxd').write_bytes(new)
print('18 comment fields positioned immediately beside their targets. Verified: every non-comment object exactly unchanged, all cables and parameters exactly unchanged, no comment/object overlaps.')
if '--apply'in sys.argv:
 assert P.read_bytes()==raw
 backup=Path('work')/('Freqshiftdelays_m4l.before_comments_only_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.amxd');backup.write_bytes(raw)
 P.write_bytes(new);assert P.read_bytes()==new;print('Saved and read back. Backup:',backup.resolve())
