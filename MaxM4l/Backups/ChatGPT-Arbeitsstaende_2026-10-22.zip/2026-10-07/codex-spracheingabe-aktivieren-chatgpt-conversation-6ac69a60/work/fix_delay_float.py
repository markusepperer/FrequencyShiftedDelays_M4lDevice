from pathlib import Path
import json,copy,struct,hashlib,datetime
P=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/Freqshiftdelays_m4l.amxd');raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d)
def bs(q):return {x['box']['id']:x['box'] for x in q['boxes']}
q=bs(d['patcher'])['obj-4']['patcher'];b=bs(q);h=bs(b['obj-135']['patcher']);s=bs(b['obj-33']['patcher']);changes=[]
def obj(x,text,outs):
 changes.append(x['id']+': '+x.get('text',x['maxclass'])+' → '+text);x.update(text=text,outlettype=outs)
def num(x):
 changes.append(x['id']+': number → flonum');x['maxclass']='flonum';x['format']=6
obj(b['obj-1020'],'f',['float'])
obj(s['obj-481'],'f',['float']);num(s['obj-467']);num(b['obj-78'])
for id in ['obj-295','obj-291','obj-288']:obj(h[id],'f',['float'])
for id in ['obj-561','obj-283']:num(h[id])
obj(h['obj-301'],'t b f',['bang','float']);obj(h['obj-281'],'pack f f',['']);obj(h['obj-1'],'change 0.',['float','int','int'])
h['kug-init-history-doc']['text']='Die zurückgeführte Zeit wird über inlet → change 0. → f als bisheriger Wert gespeichert. Alle Zeitwerte bleiben Fließkommazahlen. Die Zielzeit wird erst mit setbang3 über die bestehende 20-ms-Rampe übernommen.'
# Wiring, object identities/positions and parameter definitions must stay identical.
def check(a,z):
 assert a['lines']==z['lines'];assert a.get('parameters')==z.get('parameters');aa=bs(a);zz=bs(z);assert aa.keys()==zz.keys()
 for id,x in aa.items():
  y=zz[id];assert x.get('patching_rect')==y.get('patching_rect');assert x.get('saved_attribute_attributes')==y.get('saved_attribute_attributes')
  if 'patcher'in x:check(x['patcher'],y['patcher'])
check(old['patcher'],d['patcher'])
# Test fractional target preservation through the stored master/factor and shadow calculations.
tests=[]
for v in [29.999998,30.,30.25,177.125,191.75,9999.999]:
 times=[v*f for f in [1.,1.5,2.,3.]];shadow=[float(v)*f for f in [1.,1.5,2.,3.]];assert times==shadow
 tests.append({'master':v,'times':times})
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';head=bytearray(raw[:32]);head[28:32]=struct.pack('<I',len(payload));Path('work/delay_float.prepared.amxd').write_bytes(bytes(head)+payload)
stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');m={'device':str(P),'backup':str(P.parent/'Backups'/('vor_Delayzeit_Float_'+stamp)),'protocol':str(P.parent/('Protokoll_Delayzeit_Float_'+stamp+'.md')),'hash':hashlib.sha256(raw).hexdigest(),'changes':changes,'tests':tests};Path('work/delay_float_manifest.json').write_text(json.dumps(m));print(json.dumps(m))
