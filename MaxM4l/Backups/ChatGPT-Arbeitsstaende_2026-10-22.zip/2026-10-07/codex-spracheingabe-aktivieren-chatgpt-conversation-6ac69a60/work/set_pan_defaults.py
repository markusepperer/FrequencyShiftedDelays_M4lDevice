from pathlib import Path
import json,copy,datetime,sys
p=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/MS_4Inputs_Pan_Mix.maxpat')
raw=p.read_bytes();d=json.loads(raw);old=copy.deepcopy(d)
for id,value in [('c0pan',-100.),('c1pan',100.)]:
 b=next(z['box'] for z in d['patcher']['boxes'] if z['box']['id']==id)
 v=b['saved_attribute_attributes']['valueof'];assert v['parameter_mmin']==-100. and v['parameter_mmax']==100.
 v['parameter_initial']=[value];v['parameter_initial_enable']=1
# Confirm only the two requested default values changed.
check=copy.deepcopy(d)
for id in ['c0pan','c1pan']:
 b=next(z['box'] for z in check['patcher']['boxes'] if z['box']['id']==id)
 prior=next(z['box'] for z in old['patcher']['boxes'] if z['box']['id']==id)
 b['saved_attribute_attributes']['valueof']['parameter_initial']=prior['saved_attribute_attributes']['valueof']['parameter_initial']
assert check==old
new=json.dumps(d,ensure_ascii=False,indent=4).encode();assert json.loads(new)==d
Path('work/MS_4Inputs_Pan_Mix.pan_defaults_prepared.maxpat').write_bytes(new)
print('Prepared: Up -100 (left), Down +100 (right), all other attributes and wiring unchanged. Shared mixer used in all four instances.')
if '--apply' in sys.argv:
 assert p.read_bytes()==raw
 backup=Path('work')/('MS_4Inputs_Pan_Mix.before_pan_defaults_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.maxpat');backup.write_bytes(raw)
 p.write_bytes(new);assert p.read_bytes()==new
 print('Applied and read back; backup:',backup.resolve())
