from pathlib import Path
import json,copy,struct,datetime,math,sys
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
ns=['MS_4Inputs_Pan_Mix.maxpat','MS_MatrixreceiveShadows.maxpat','Freqshiftdelays_m4l.amxd'];raw={n:(R/n).read_bytes() for n in ns}
def dec(n,b):return json.JSONDecoder().raw_decode(b[32:].decode())[0] if n.endswith('.amxd') else json.loads(b)
nds={n:dec(n,b) for n,b in raw.items()};old=copy.deepcopy(nds)
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def add(q,id,text,rect,ni,no,types=None,cls='newobj',**kw):
 assert id not in bs(q)
 b=dict(id=id,maxclass=cls,patching_rect=rect,numinlets=ni,numoutlets=no,**kw)
 if text is not None:b['text']=text
 if types is not None:b['outlettype']=types
 q['boxes'].append({'box':b});return b
def edge(q,a,ao,b,bi):q['lines'].append({'patchline':{'source':[a,ao],'destination':[b,bi]}})
def rem(q,a,ao,b,bi):
 es=[e for e in q['lines'] if e['patchline']['source']==[a,ao] and e['patchline']['destination']==[b,bi]];assert len(es)==1,(a,b);q['lines'].remove(es[0])
def helper():
 q={'fileversion':1,'classnamespace':'box','rect':[100.,100.,950.,550.],'boxes':[],'lines':[]}
 for i in range(5):add(q,f'in{i}',None,[30.+i*180,40.,30.,30.],0,1,['signal'] if i<4 else ['float'],cls='inlet',index=i+1,comment=['Shift-Mix Up','Shift-Mix Down','Delay ohne Shift separat','Mikrofon direkt','Delay-Mix 0..1'][i])
 add(q,'clip','clip 0. 1.',[750.,110.,110.,22.],3,1,['float'])
 add(q,'pack','pack 0. 30',[750.,150.,110.,22.],2,1,[''])
 add(q,'ramp','line~ 1.',[750.,190.,110.,22.],2,2,['signal','bang'])
 add(q,'inverse','!-~ 1.',[750.,240.,80.,22.],2,1,['signal'])
 for i in range(4):
  add(q,f'gain{i}','*~',[30.+i*180,320.,60.,22.],2,1,['signal'])
  add(q,f'out{i}',None,[30.+i*180,390.,30.,30.],1,0,cls='outlet',index=i+1)
  edge(q,f'in{i}',0,f'gain{i}',0);edge(q,'ramp' if i<3 else 'inverse',0,f'gain{i}',1);edge(q,f'gain{i}',0,f'out{i}',0)
 for a,b in [('in4','clip'),('clip','pack'),('pack','ramp'),('ramp','inverse')]:edge(q,a,0,b,0)
 add(q,'doc','Wet = alle drei Delayzweige x; Dry = Mikrofon (1-x). Bestehende Pegel und Pan bleiben wirksam. Linear, 30 ms. Default x=1: nur Delay.',[30.,450.,850.,45.],1,0,cls='comment')
 return q
m=nds[ns[0]]['patcher'];s=nds[ns[1]]['patcher'];d=nds[ns[2]]['patcher']
control=copy.deepcopy(bs(m)['shift-mix']);control.update(id='delay-mix',varname='mix_delay_blend',patching_rect=[500.,540.,455.,31.],presentation_rect=[174.,239.,153.,31.],hint='0 % Mikrofon direkt; 100 % gesamte Delay-Mischung einschließlich Delay ohne Shift. Vorhandene Pegel sind Grundpegel: Mikrofon direkt muss für die Dry-Seite aufgedreht sein.')
v=control['saved_attribute_attributes']['valueof'];v.update(parameter_initial=[100.],parameter_initial_enable=1,parameter_longname='Delay-Mix',parameter_shortname='Delay-Mix',parameter_mmin=0.,parameter_mmax=100.,parameter_type=0,parameter_unitstyle=5,parameter_invisible=0)
m['boxes'].append({'box':control})
for src,id,text,x,w in [('shift-mix-label','delay-mix-label','DELAY-MIX',174.,153.),('shift-mix-left','delay-mix-left','Direkt',174.,55.),('shift-mix-right','delay-mix-right','Delay',280.,47.)]:
 b=copy.deepcopy(bs(m)[src]);b.update(id=id,text=text);b['presentation_rect'][0]=x;b['presentation_rect'][2]=w;b['patching_rect'][0]+=500.;m['boxes'].append({'box':b})
add(m,'delay-mix-normalize','/ 100.',[500.,590.,80.,22.],2,1,['float'])
add(m,'delay-mix-shadow-message','prepend delaymix',[610.,590.,140.,22.],1,1,[''])
for q in [m,s]:add(q,'delay-mix-audio','p Delay_Mix',[500.,850.,260.,22.],5,4,['signal']*4,patcher=helper())
for i in range(4):
 src,port=('shift-mix-audio',i) if i<2 else (f'c{i}in',0)
 rem(m,src,port,f'c{i}channel',0);edge(m,src,port,'delay-mix-audio',i);edge(m,'delay-mix-audio',i,f'c{i}channel',0)
 src,port=('shift-mix-audio',i) if i<2 else (f'in{i}',0)
 rem(s,src,port,'matrix',i);edge(s,src,port,'delay-mix-audio',i);edge(s,'delay-mix-audio',i,'matrix',i)
edge(m,'delay-mix',0,'delay-mix-normalize',0);edge(m,'delay-mix-normalize',0,'delay-mix-audio',4);edge(m,'delay-mix-normalize',0,'delay-mix-shadow-message',0);edge(m,'delay-mix-shadow-message',0,'controlout',0)
# Original shiftmix route preserves all matrix lists; insert delaymix route on its unmatched outlet.
rem(s,'shift-mix-route',1,'matrix',0)
add(s,'delay-mix-route','route delaymix',[825.,260.,135.,22.],1,2,['',''])
edge(s,'shift-mix-route',1,'delay-mix-route',0);edge(s,'delay-mix-route',0,'delay-mix-audio',4);edge(s,'delay-mix-route',1,'matrix',0)
# Emit both restored blend values before the existing pan/level refresh.
rem(m,'shift-mix-init',0,'refresh',0)
add(m,'delay-mix-init','t b b',[690.,150.,65.,22.],1,2,['bang','bang'])
edge(m,'shift-mix-init',0,'delay-mix-init',0);edge(m,'delay-mix-init',1,'delay-mix',0);edge(m,'delay-mix-init',0,'refresh',0)
m.setdefault('parameters',{})['delay-mix']=['Delay-Mix','Delay-Mix',0]
bs(m)['start']['text']='Zehn Live-Parameter: vier Pegel, vier Panoramen, Shift-Mix und Delay-Mix.'
bs(m)['technical']['text']='Shift-Mix vor Up/Down-Pegel; Delay-Mix gewichtet alle Delayzweige gegen Mikrofon direkt. Ausgang 3: Matrixwerte, shiftmix und delaymix an Schatten.'
bs(s)['note']['text']='Schatten-Audio mit identischem Shift-Mix, Delay-Mix und Pegel/Pan. Eingang 5: Matrixlisten sowie shiftmix und delaymix 0..1. Keine eigenen Live-Parameter.'
p=next(z['box']['patcher'] for z in d['boxes'] if z['box']['id']=='obj-4')
for i,id in enumerate(['obj-80','obj-81','obj-82','obj-83'],1):
 assert bs(p)[id]['name']==ns[0]
 key=f'obj-4::{id}::delay-mix';name=f'D{i} Delay-Mix'
 d['parameters'][key]=[name,name,0];d['parameters']['parameter_overrides'][key]={'parameter_longname':name,'parameter_shortname':name,'parameter_invisible':0}
def check(q):
 b=bs(q);assert len(b)==len(q['boxes'])
 for e in q['lines']:
  a,ao=e['patchline']['source'];c,ci=e['patchline']['destination'];assert a in b and c in b;assert ao<b[a]['numoutlets'] and ci<b[c]['numinlets']
 for z in b.values():
  if 'patcher'in z:check(z['patcher'])
for doc in nds.values():check(doc['patcher'])
for k,v in old[ns[2]]['patcher']['parameters'].items():
 if k=='parameter_overrides':assert all(d['parameters'][k][a]==b for a,b in v.items())
 else:assert d['parameters'][k]==v
for i in range(4):
 for suffix in ['level','pan']:assert bs(m)[f'c{i}{suffix}']==bs(old[ns[0]]['patcher'])[f'c{i}{suffix}']
assert bs(m)['shift-mix']==bs(old[ns[0]]['patcher'])['shift-mix']
assert bs(m)['delay-mix-audio']['patcher']==bs(s)['delay-mix-audio']['patcher']
# Independently moving wet levels and stereo pans: scaling all wet inputs equals scaling their final sum.
for x in [0.,.25,.5,.75,1.]:
 for levels in [(0.,0.,.7,.8),(.2,.9,0.,.8),(.7,.1,.3,.8)]:
  signals=[.31,-.17,.23,.4];pans=[-.7,.8,.1,-.2]
  for side,fn in enumerate([math.cos,math.sin]):
   terms=[a*b*fn((p+1)*math.pi/4) for a,b,p in zip(signals,levels,pans)]
   result=sum(terms[i]*x for i in range(3))+terms[3]*(1-x)
   assert abs(result-(x*sum(terms[:3])+(1-x)*terms[3]))<1e-12
   if x==0:assert result==terms[3]
   if x==1:assert abs(result-sum(terms[:3]))<1e-12
# Verify only three original audio-to-channel connections plus the two shift outputs changed as designed.
for a,b in [('c2in','shift-mix-audio')]:assert any(e['patchline']['source']==[a,0] and e['patchline']['destination']==[b,2] for e in m['lines'])
out=Path('work/delay_mix_prepared');out.mkdir(exist_ok=True);new={}
for n,doc in nds.items():
 payload=json.dumps(doc,ensure_ascii=False,indent=4).encode()
 if n.endswith('.amxd'):
  payload+=b'\0';h=bytearray(raw[n][:32]);h[28:32]=struct.pack('<I',len(payload));payload=bytes(h)+payload
 assert dec(n,payload)==doc;new[n]=payload;(out/n).write_bytes(payload)
print('Prepared and validated: main/shadow graph, preserved old parameters and levels, full wet bus including plain delay, 0/50/100% endpoint math. Four new automated Delay-Mix parameters, default 100%.')
if '--apply'in sys.argv:
 assert all((R/n).read_bytes()==raw[n] for n in ns)
 backup=Path('work')/('delay_mix_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
 for n,b in raw.items():(backup/n).write_bytes(b)
 for n,b in new.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Applied and read back. Backup:',backup.resolve())
