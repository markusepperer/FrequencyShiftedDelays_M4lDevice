from pathlib import Path
import json,copy,struct,datetime,sys,hashlib,heapq,itertools
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l');P=R/'Freqshiftdelays_m4l.amxd';raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d)
STAMP=(json.loads(Path('work/timechange_lock_manifest.json').read_text())['backup_dir'].rsplit('_',2)[-2]+'_'+json.loads(Path('work/timechange_lock_manifest.json').read_text())['backup_dir'].rsplit('_',2)[-1]) if '--apply' in sys.argv else datetime.datetime.now().strftime('%Y%m%d_%H%M%S');backup_name='komplett_vor_Zeitwechsel_Sperre_'+STAMP;report_name='Protokoll_Zeitwechsel_Sperre_'+STAMP+'.md'
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def edge(q,a,ao,b,bi,**kw):q['lines'].append({'patchline':{'source':[a,ao],'destination':[b,bi],**kw}})
def add(q,id,cls,text,rect,ni,no,types=None,**kw):
 assert id not in bs(q)
 ob=dict(id=id,maxclass=cls,patching_rect=rect,numinlets=ni,numoutlets=no,**kw)
 if text is not None:ob['text']=text
 if types is not None:ob['outlettype']=types
 q['boxes'].append({'box':ob});return ob
q=next(z['box']['patcher'] for z in d['patcher']['boxes'] if z['box']['id']=='obj-4');b=bs(q);assert 'timechange-lock'not in b
h={'fileversion':1,'appversion':copy.deepcopy(q['appversion']),'classnamespace':'box','rect':[100.,100.,1000.,650.],'boxes':[],'lines':[]}
add(h,'request','inlet',None,[40.,55.,30.,30.],0,1,['bang'],index=1,comment='Trigger anfordern (MIDI/Maus/Startbang)')
add(h,'complete','inlet',None,[510.,55.,30.,30.],0,1,['bang'],index=2,comment='Schattenzeiten wurden nachgeführt')
add(h,'gate','newobj','gate 1 1',[40.,160.,90.,22.],2,1,[''])
add(h,'accept','newobj','t b b',[40.,215.,65.,22.],1,2,['bang','bang'])
add(h,'close','message','0',[165.,215.,40.,22.],2,1,[''])
add(h,'release-delay','newobj','delay 100',[510.,160.,90.,22.],2,1,['bang'])
add(h,'open','message','1',[510.,215.,40.,22.],2,1,[''])
add(h,'out','outlet',None,[40.,300.,30.,30.],1,0,index=1,comment='Ein akzeptierter Trigger zur vorhandenen Sequenz')
for a,ao,c,ci in [('request',0,'gate',1),('gate',0,'accept',0),('accept',1,'close',0),('close',0,'gate',0),('accept',0,'out',0),('complete',0,'release-delay',0),('release-delay',0,'open',0),('open',0,'gate',0)]:edge(h,a,ao,c,ci)
notes=[('doc-request','Alle Startwege treffen auf dieselbe Sperre. gate 1 1 startet offen. Bei geschlossenem Gate werden Trigger verworfen, weder gespeichert noch nachgeholt.',[145.,55.,340.,72.]),('doc-accept','t b b: rechts zuerst Gate schließen, erst danach links die Sequenz starten. Auch direkt aufeinanderfolgende Startmeldungen können dadurch nur einen Wechsel auslösen.',[235.,205.,260.,95.]),('doc-complete','Dieser Bang kommt vom Ende des vorhandenen Fade-Timers – nachdem reset-shadow-delaytimes gesendet wurde. Keine zweite Berechnung der musikalischen Fade-Zeit.',[565.,55.,365.,78.]),('doc-release','100 ms warten: 50 ms interne Schatten-Zeitrampen + 50 ms Sicherheitsabstand. Erst danach Gate wieder öffnen. Der Fade selbst bleibt unverändert.',[615.,155.,325.,75.]),('doc-time','Gesamtsperre ab akzeptiertem Trigger: 650 ms Vorlauf + verwendeter Fade + 100 ms Nachlauf. Bei 3 s Fade: Freigabe nach 3,75 s. Währenddessen dürfen neue Zielwerte vorgemerkt werden.',[40.,370.,875.,65.]),('doc-midi','Die vorhandene 50-ms-MIDI-Button-Rücksetzung bleibt außerhalb dieser Sperre erhalten. Der Button springt zurück, auch wenn sein neuer Trigger während des laufenden Wechsels verworfen wird.',[40.,460.,875.,65.])]
for id,text,rect in notes:add(h,id,'comment',text,rect,1,0,fontsize=12.)
add(q,'timechange-lock','newobj','p Zeitwechsel-Sperre',[25.,-175.,140.,22.],2,1,['bang'],patcher=h)
add(q,'timechange-lock-note','comment','Gemeinsame Triggersperre.\nDoppelklick: Ablauf und\nFreigabe erklärt.',[25.,-225.,140.,45.],1,0,fontsize=10.,presentation=0,linecount=3)
# All existing input paths to the start of the sequence are routed through this one gate.
starts=[e for e in q['lines'] if e['patchline']['destination']==['obj-113',0]]
assert {tuple(e['patchline']['source']) for e in starts}=={('midi-trigger-fanout',0),('obj-9',0)}
for e in starts:e['patchline']['destination']=['timechange-lock',0]
edge(q,'timechange-lock',0,'obj-113',0)
# Right before scheduling the internal release guard, finish shadow parameter dispatch synchronously.
completion=[e for e in q['lines'] if e['patchline']['source']==['obj-556',0]]
assert len(completion)==1 and completion[0]['patchline']['destination']==['obj-568',0]
completion[0]['patchline']['order']=0
edge(q,'obj-556',0,'timechange-lock',1,order=1)
if 'timefade-doc-midi-trigger-reset-order'in b:
 b['timefade-doc-midi-trigger-reset-order']['text']='Button nach 50 ms zurücksetzen.\nSequenzsperre separat: p Zeitwechsel-Sperre.'
 b['timefade-doc-midi-trigger-reset-order']['linecount']=2
# Ensure all original functional objects and their positions are byte-for-byte equivalent after JSON decoding.
oq=next(z['box']['patcher'] for z in old['patcher']['boxes'] if z['box']['id']=='obj-4');ob=bs(oq)
for id,obj in ob.items():
 if obj['maxclass']!='comment':assert bs(q)[id]==obj,id
 else:assert bs(q)[id]['patching_rect']==obj['patching_rect']
assert d['patcher']['parameters']==old['patcher']['parameters']
def validate(p):
 bb=bs(p);assert len(bb)==len(p['boxes'])
 for e in p['lines']:
  a,ao=e['patchline']['source'];c,ci=e['patchline']['destination'];assert a in bb and c in bb and ao<bb[a]['numoutlets'] and ci<bb[c]['numinlets'],(a,ao,c,ci)
 for obj in bb.values():
  if 'patcher'in obj:validate(obj['patcher'])
validate(d['patcher'])
# Event simulator follows saved graph, including nested gate, right-to-left triggers and send/receives.
flat={};links={}
def flatten(p,prefix=''):
 for z in p['boxes']:
  obj=z['box'];id=prefix+obj['id'];flat[id]=obj
  if 'patcher'in obj and id=='timechange-lock':flatten(obj['patcher'],id+'/')
 for e in p['lines']:
  l=e['patchline'];a,ao=l['source'];c,ci=l['destination'];links.setdefault((prefix+a,ao),[]).append((l.get('order',0),prefix+c,ci))
flatten(q)
for key in links:links[key].sort()
bus='---dynamischerampe_fades';receivers=[id for id,obj in flat.items() if obj.get('text')=='receive '+bus];matrices=['obj-117','obj-124','obj-134','obj-146']
results=[]
def simulate(seconds,changes=False):
 state={'timefade-store':1000.,'obj-115':100.,'obj-544':550.,'obj-556':1000.,'timechange-lock/gate':1,'timechange-lock/release-delay':100.};events=[];counter=itertools.count();trace=[];now=[0.]
 def schedule(t,kind,id,port=0,v='bang'):heapq.heappush(events,(t,next(counter),kind,id,port,v))
 def emit(id,port,v):
  for _,dest,inp in links.get((id,port),[]):receive(dest,inp,v)
 def receive(id,inp,v):
  obj=flat[id];text=obj.get('text','')
  if id=='timechange-lock':receive('timechange-lock/request' if inp==0 else 'timechange-lock/complete',0,v);return
  if id.startswith('timechange-lock/') and obj['maxclass']=='inlet':emit(id,0,v);return
  if id=='timechange-lock/out':trace.append((now[0],'accepted',v));emit('timechange-lock',0,v);return
  if id=='timechange-lock/gate':
   if inp==0:
    state[id]=int(v);trace.append((now[0],'gate',v))
   elif state[id]:emit(id,0,v)
   else:trace.append((now[0],'blocked',v))
   return
  if id in ['timechange-lock/open','timechange-lock/close']:emit(id,0,int(text));return
  if id in ['direct-shadow-select','obj-528','obj-568','obj-195','obj-566']:trace.append((now[0],id,v));return
  if id in matrices:
   if isinstance(v,tuple):trace.append((now[0],id,v))
   return
  if text=='send '+bus:
   for rec in receivers:emit(rec,0,v)
   return
  if id=='timefade-ms':emit(id,0,float(v)*1000.);return
  if id=='timefade-store':
   if inp==1:state[id]=v
   else:emit(id,0,state[id] if v=='bang' else v)
   return
  if id in ['obj-115','obj-544','obj-556','timechange-lock/release-delay']:
   if inp==1:state[id]=float(v)
   elif v=='bang':schedule(now[0]+state[id],'emit',id)
   return
  if id=='timefade-ramp':emit(id,0,('ramp',v));return
  if id=='timefade-protect100':emit(id,0,100.);return
  if text.startswith('t '):
   types=text.split()[1:]
   for port in range(len(types)-1,-1,-1):emit(id,port,'bang' if types[port]=='b' else v)
 end=650.+seconds*1000.;release=end+100.
 receive('timefade-ms',0,seconds)
 # Different entry paths, same scheduler tick and repeats throughout the active fade and guard.
 requests=[(0.,'midi-trigger-fanout',0),(0.,'obj-9',0),(500.,'obj-9',0),(649.,'midi-trigger-fanout',0),(end-1.,'obj-9',0),(end,'obj-9',0),(release-1.,'obj-9',0),(release+1.,'obj-9',0)]
 for t,id,port in requests:schedule(t,'emit',id,port)
 if changes:schedule(900.,'receive','timefade-ms',0,.1)
 while events:
  t,_,kind,id,port,v=heapq.heappop(events);now[0]=t
  (emit if kind=='emit' else receive)(id,port,v)
 accepted=[t for t,id,v in trace if id=='accepted'];assert accepted==[0.,release+1.],(seconds,trace)
 main=[t for t,id,v in trace if id=='obj-195'];assert main==[100.,release+101.],(seconds,main)
 resets=[t for t,id,v in trace if id=='obj-568'];secondfade=100. if changes else seconds*1000.
 assert resets==[end,release+1.+650.+secondfade],(seconds,resets)
 unlocks=[t for t,id,v in trace if id=='gate' and v==1];assert unlocks==[release,resets[1]+100.]
 for id in matrices:
  ramps=[(t,v) for t,oid,v in trace if oid==id]
  assert ramps==[(0.,('ramp',100.)),(650.,('ramp',seconds*1000.)),(release+1.,('ramp',100.)),(release+651.,('ramp',secondfade))],(id,ramps)
 return {'fade_s':seconds,'shadow_update_ms':end,'release_ms':release,'requests':len(requests),'accepted':2,'blocked':len([1 for t,id,v in trace if id=='blocked']),'mid_fade_duration_edit':changes}
for seconds in [.1,1.,3.,10.]:results.append(simulate(seconds))
results.append(simulate(3.,True))
newpayload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';header=bytearray(raw[:32]);header[28:32]=struct.pack('<I',len(newpayload));new=bytes(header)+newpayload;assert json.JSONDecoder().raw_decode(new[32:].decode())[0]==d
# Snapshot every active root patch file and prior protocol; no duplicate user-facing device is created.
backup_sources={f.name:f.read_bytes() for f in R.iterdir() if f.is_file() and f.suffix in ['.maxpat','.amxd','.md']}
report='''# Zeitwechsel-Sperre\n\n## Änderung\n\nGemeinsame Sperre vor der bestehenden Umschaltsequenz. MIDI-/Maus-Trigger und der interne Startbang laufen durch `p Zeitwechsel-Sperre`. Ein akzeptierter Trigger schließt zuerst das Gate und startet danach die vorhandene Sequenz. Weitere Trigger werden verworfen; es gibt keine Warteschlange.\n\n## Freigabe\n\nDer vorhandene Fade-Endtimer (`obj-556`) sendet zuerst `reset-shadow-delaytimes`. Anschließend wird die Freigabe angestoßen. Im Sperr-Unterpatch wartet `delay 100` auf die 50-ms-Zeitrampen der Schatten plus 50-ms-Sicherheitsabstand. Dann öffnet das Gate wieder. Die Freigabe hängt damit am tatsächlichen Fade-Endereignis, nicht an einem parallel berechneten Fade-Timer.\n\nBei 3 s Fade: Hauptzeiten ab100 ms, Rückblende ab650 ms, Schatten-Nachführung nach3650 ms, nächste Freigabe nach3750 ms.\n\nDie vorhandene 50-ms-MIDI-Button-Rücksetzung bleibt unverändert und unabhängig von der Sequenzsperre. Numberbox und Zielwerte bleiben bedienbar. Die Fade-Dauer wird weiterhin beim Rückblendenbeginn aus ihrem Speicher gelesen. Eine spätere Änderung beeinflusst den laufenden Fade-Timer nicht.\n\n## Layout und Parameter\n\nKeine vorhandenen Funktionsobjekte verschoben oder geändert. Keine Live-Parameter hinzugefügt, umbenannt oder neu registriert. Ein neuer kleiner Unterpatch mit Kommentaren wurde im freien Bereich links bei den Triggern ergänzt. Der alte Kommentar zur fehlenden Sperre wurde berichtigt. Die Live-Präsentation bleibt unverändert.\n\n## Prüfung\n\nGespeicherte Verbindungen und Ein-/Ausgangsgrenzen geprüft. Die tatsächliche gespeicherte Ereignisverschaltung mit rechter-vor-linker Triggerreihenfolge, Send/Receive und verschachteltem Gate simuliert. Testfälle: gleichzeitige Trigger beider Startwege; zweiter Trigger nach500 ms; Trigger während Fade, am Fade-Ende und während Sicherheitsnachlauf; erster Trigger nach Freigabe; Fade-Zeitänderung während der Rückblende.\n\n'''
report+='| Fade | Schatten-Nachführung | Freigabe |\n|---|---|---|\n'
for res in results[:4]:report+=f"| {res['fade_s']} s | {res['shadow_update_ms']/1000:g} s | {res['release_ms']/1000:g} s |\n"
report+='\nAlle Simulationen bestanden. Kein Laufzeit-/Hörtest in Ableton durchgeführt; dieser muss im geöffneten Gerät erfolgen. Sicherheitsnachlauf setzt weiterhin interne Schatten-Zeitrampen von50 ms voraus.\n\n## Sicherung\n\nKomplette aktive Patchdateien und vorhandene Markdown-Protokolle vor Änderung gesichert unter `Backups/'+backup_name+'`. SHA-256-Prüfsummen liegen im Sicherungsordner. Die Live-Set-Datei wird nicht verändert.\n'
Path('work/timechange_lock.prepared.amxd').write_bytes(new);Path('work/timechange_lock_protocol.prepared.md').write_text(report)
manifest={'backup_dir':str(R/'Backups'/backup_name),'protocol':str(R/report_name),'source_sha256':hashlib.sha256(raw).hexdigest(),'tests':results};Path('work/timechange_lock_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False))
if '--apply'in sys.argv:
 assert P.read_bytes()==raw
 back=R/'Backups'/backup_name;back.mkdir()
 for n,data in backup_sources.items():(back/n).write_bytes(data)
 (back/'SHA256.json').write_text(json.dumps({n:hashlib.sha256(data).hexdigest() for n,data in backup_sources.items()},indent=2))
 assert all((back/n).read_bytes()==data for n,data in backup_sources.items())
 P.write_bytes(new);assert P.read_bytes()==new
 (R/report_name).write_text(report)
 print('Applied, complete backup verified, protocol written. Existing Live Set untouched.')
