from pathlib import Path
import json,collections
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
def read(p):
 b=p.read_bytes()
 try:return json.loads(b)
 except (ValueError,UnicodeDecodeError):return json.JSONDecoder().raw_decode(b[32:].decode())[0]
current={p.name:read(p) for p in R.iterdir() if p.suffix in ['.maxpat','.amxd']}
files=[p for p in (R/'Backups').rglob('*') if p.is_file() and ('.maxpat'in p.name or '.amxd'in p.name)]
files+=list(Path('work').glob('*backup*/*.maxpat'))+list(Path('work').glob('*backup*/*.amxd'))
findings=[];errors=[];checks=0
for p in files:
 try:d=read(p)
 except Exception as e:errors.append([str(p),str(e)]);continue
 siblings={f.name:f for f in p.parent.iterdir() if f.suffix in ['.maxpat','.amxd']}
 def walk(q,path):
  global checks
  b={z['box']['id']:z['box'] for z in q.get('boxes',[])}
  for e in q.get('lines',[]):
   checks+=1;l=e['patchline'];a,ao=l['source'];c,ci=l['destination']
   if a not in b or c not in b:findings.append({'file':str(p),'path':path,'kind':'missing object','line':l});continue
   for id,port,kind in [(a,ao,'numoutlets'),(c,ci,'numinlets')]:
    obj=b[id];n=obj.get(kind,0);target=None;sub=obj.get('patcher');resolution='embedded'
    if sub is None:
     target=obj.get('name') if obj['maxclass']=='bpatcher' else obj.get('text','').split(' ')[0]+'.maxpat'
     if target in siblings:sub=read(siblings[target])['patcher'];resolution='same backup'
     elif target in current:sub=current[target]['patcher'];resolution='current fallback'
    if sub is not None:n=sum(z['box']['maxclass']==('inlet' if kind=='numinlets' else 'outlet') for z in sub.get('boxes',[]))
    if port>=n:findings.append({'file':str(p),'path':path,'object':id,'text':obj.get('text',obj.get('name')),'kind':kind,'port':port,'available':n,'cached':obj.get(kind),'resolution':resolution,'line':l})
  for id,obj in b.items():
   if 'patcher'in obj:walk(obj['patcher'],path+'/'+id)
 walk(d['patcher'],'')
report={'files':len(files),'connections_checked':checks,'findings':findings,'read_errors':errors}
Path('work/historical_patchcord_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Files:',len(files),'Connections:',checks,'Findings:',len(findings),'Read errors:',len(errors))
for f in findings:print(json.dumps(f,ensure_ascii=False))
