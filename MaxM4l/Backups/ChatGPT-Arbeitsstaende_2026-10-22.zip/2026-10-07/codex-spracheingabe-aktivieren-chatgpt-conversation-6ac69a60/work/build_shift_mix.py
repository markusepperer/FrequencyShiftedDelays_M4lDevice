from pathlib import Path
import json,copy,struct,hashlib,sys,datetime,math
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
NAMES=['MS_4Inputs_Pan_Mix.maxpat','MS_MatrixreceiveShadows.maxpat','Freqshiftdelays_m4l.amxd']
raw={n:(R/n).read_bytes() for n in NAMES}
def decode(n,b):return json.JSONDecoder().raw_decode(b[32:].decode())[0] if n.endswith('.amxd') else json.loads(b)
docs={n:decode(n,b) for n,b in raw.items()};original=copy.deepcopy(docs)
def boxes(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def add(q,id,cls,text,rect,ni,no,types=None,**kw):
 assert id not in boxes(q)
 b={'id':id,'maxclass':cls,'patching_rect':rect,'numinlets':ni,'numoutlets':no,**kw}
 if text is not None:b['text']=text
 if types is not None:b['outlettype']=types
 q['boxes'].append({'box':b});return b
def edge(q,a,ao,b,bi):q['lines'].append({'patchline':{'source':[a,ao],'destination':[b,bi]}})
def remove(q,a,ao,b,bi):
 match=[e for e in q['lines'] if e['patchline']['source']==[a,ao] and e['patchline']['destination']==[b,bi]]
 assert len(match)==1,(a,b);q['lines'].remove(match[0])
def crossfade():
 q={'fileversion':1,'appversion':{'major':9,'minor':1,'revision':4,'architecture':'x64','modernui':1},'classnamespace':'box','rect':[100.,100.,860.,540.],'boxes':[],'lines':[]}
 for i,(id,label) in enumerate([('up','Shift Up'),('down','Shift Down'),('dry','Delay ohne Shift vor eigenem Fader'),('mix','Anteil ohne Shift 0..1')]):
  add(q,id,'inlet',None,[30.+i*200,45.,30.,30.],0,1,['signal'] if i<3 else ['float'],index=i+1,comment=label)
 add(q,'clip','newobj','clip 0. 1.',[630.,110.,110.,22.],3,1,['float'])
 add(q,'pack','newobj','pack 0. 30',[630.,150.,110.,22.],2,1,[''])
 add(q,'ramp','newobj','line~ 0.',[630.,190.,110.,22.],2,2,['signal','bang'])
 add(q,'inverse','newobj','!-~ 1.',[490.,230.,80.,22.],2,1,['signal'])
 for id,x in [('up-shift',30.),('down-shift',230.),('dry-shared',430.)]:add(q,id,'newobj','*~',[x,300.,60.,22.],2,1,['signal'])
 for id,x in [('up-sum',30.),('down-sum',230.)]:add(q,id,'newobj','+~',[x,360.,60.,22.],2,1,['signal'])
 for i,id in enumerate(['up-out','down-out']):add(q,id,'outlet',None,[30.+i*200,420.,30.,30.],1,0,index=i+1,comment='Zum bestehenden Pegel/Pan und zur Matrix')
 add(q,'doc','comment','Vor Pegel/Pan: Up = (1-x)*Up + x*Delay; Down = (1-x)*Down + x*Delay. Linear, 30 ms geglättet. Dritter Delay-Fader und Mikrofon bleiben unabhängig.',[30.,470.,790.,45.],1,0,linecount=2)
 for a,ao,b,bi in [('mix',0,'clip',0),('clip',0,'pack',0),('pack',0,'ramp',0),('ramp',0,'inverse',0),('up',0,'up-shift',0),('down',0,'down-shift',0),('dry',0,'dry-shared',0),('inverse',0,'up-shift',1),('inverse',0,'down-shift',1),('ramp',0,'dry-shared',1),('up-shift',0,'up-sum',0),('down-shift',0,'down-sum',0),('dry-shared',0,'up-sum',1),('dry-shared',0,'down-sum',1),('up-sum',0,'up-out',0),('down-sum',0,'down-out',0)]:edge(q,a,ao,b,bi)
 return q
main=docs[NAMES[0]]['patcher'];shadow=docs[NAMES[1]]['patcher'];device=docs[NAMES[2]]['patcher'];mb=boxes(main)
assert 'shift-mix' not in mb
control=copy.deepcopy(mb['c0pan']);control.update(id='shift-mix',varname='mix_shift_blend',patching_rect=[25.,535.,455.,31.],presentation_rect=[12.,239.,153.,31.],hint='Anteil ohne Frequency Shift in beiden bewegten Zweigen: 0 % nur Shift, 100 % nur Delay ohne Shift. Folgt Up/Down-Pegel und Panorama; separater Delay-Fader bleibt unabhängig.')
control['saved_attribute_attributes']['valueof']={'parameter_initial':[0.],'parameter_initial_enable':1,'parameter_longname':'Shift-Mix','parameter_shortname':'Shift-Mix','parameter_mmin':0.,'parameter_mmax':100.,'parameter_modmode':0,'parameter_type':0,'parameter_unitstyle':5,'parameter_invisible':0}
main['boxes'].append({'box':control})
for id,text,rect in [('shift-mix-label','SHIFT-MIX',[12.,219.,153.,18.]),('shift-mix-left','Shift',[12.,272.,54.,15.]),('shift-mix-right','Ohne Shift',[96.,272.,70.,15.])]:
 add(main,id,'comment',text,[25.,1080.+len(main['boxes']),200.,18.],1,0,presentation=1,presentation_rect=rect,fontsize=10.,textcolor=[.15,.19,.23,1.])
add(main,'shift-mix-normalize','newobj','/ 100.',[25.,575.,80.,22.],2,1,['float'])
add(main,'shift-mix-shadow-message','newobj','prepend shiftmix',[125.,575.,135.,22.],1,1,[''])
add(main,'shift-mix-audio','newobj','p Shift_Mix',[25.,650.,230.,22.],4,2,['signal','signal'],patcher=crossfade())
for i in range(2):
 remove(main,f'c{i}in',0,f'c{i}channel',0)
 edge(main,f'c{i}in',0,'shift-mix-audio',i)
 edge(main,'shift-mix-audio',i,f'c{i}channel',0)
edge(main,'c2in',0,'shift-mix-audio',2)
edge(main,'shift-mix',0,'shift-mix-normalize',0)
edge(main,'shift-mix-normalize',0,'shift-mix-audio',3)
edge(main,'shift-mix-normalize',0,'shift-mix-shadow-message',0)
edge(main,'shift-mix-shadow-message',0,'controlout',0)
# First initialize the crossfade, then recall the original pan/level values in their original order.
remove(main,'defer',0,'refresh',0)
add(main,'shift-mix-init','newobj','t b b',[580.,150.,65.,22.],1,2,['bang','bang'])
edge(main,'defer',0,'shift-mix-init',0);edge(main,'shift-mix-init',1,'shift-mix',0);edge(main,'shift-mix-init',0,'refresh',0)
main['parameters']['shift-mix']=['Shift-Mix','Shift-Mix',0]
mb=boxes(main);mb['start']['text']='Neun Live-Parameter: vier Pegel, vier Panoramen und gemeinsamer Shift-Mix.'
mb['technical']['text']='Audio 1–4 → Stereo 1–2. Ausgang 3: Matrixwerte und shiftmix an Schatten. Shift-Mix liegt vor Up/Down-Pegel und Pan.'
mb['presentnote']['text']='Automation und Speicherung im Live-Device. Shift-Mix: 0 % Shift, 100 % ohne Shift; eigene Up/Down-Hüllkurven und Pan bleiben wirksam.'
main['rect'][3]=max(main['rect'][3],1160.)
add(shadow,'shift-mix-route','newobj','route shiftmix',[825.,225.,130.,22.],1,2,['',''])
add(shadow,'shift-mix-audio','newobj','p Shift_Mix',[30.,235.,230.,22.],4,2,['signal','signal'],patcher=crossfade())
remove(shadow,'ctl',0,'matrix',0)
edge(shadow,'ctl',0,'shift-mix-route',0);edge(shadow,'shift-mix-route',1,'matrix',0);edge(shadow,'shift-mix-route',0,'shift-mix-audio',3)
for i in range(2):
 remove(shadow,f'in{i}',0,'matrix',i)
 edge(shadow,f'in{i}',0,'shift-mix-audio',i);edge(shadow,'shift-mix-audio',i,'matrix',i)
edge(shadow,'in2',0,'shift-mix-audio',2)
boxes(shadow)['note']['text']='Eigenes Schatten-Audio. Eingang 5: Matrixwerte und shiftmix 0..1 vom Hauptmixer. Gleiche Überblendung vor Up/Down-Pegel und Panorama; keine eigenen Live-Parameter.'
# Register only the four additional parameters; leave every existing parameter entry and override intact.
parent=next(z['box']['patcher'] for z in device['boxes'] if z['box']['id']=='obj-4')
for i,id in enumerate(['obj-80','obj-81','obj-82','obj-83'],1):
 b=boxes(parent)[id];assert b['name']==NAMES[0]
 b['presentation_rect'][3]=292.
 b['patching_rect'][3]=max(b['patching_rect'][3],292.)
 name=f'D{i} Shift-Mix';key=f'obj-4::{id}::shift-mix'
 device['parameters'][key]=[name,name,0]
 device['parameters'].setdefault('parameter_overrides',{})[key]={'parameter_longname':name,'parameter_shortname':name,'parameter_invisible':0}
# Move the two stereo-output meters below the taller mixer windows.
for id in ['obj-116','obj-121','obj-67','obj-69','obj-60','obj-61','obj-58','obj-59']:
 boxes(parent)[id]['presentation_rect'][1]+=76.
# Validate the graphs, parameter preservation, routing and mathematical endpoint behavior.
def validate(q):
 bs=boxes(q);assert len(bs)==len(q['boxes'])
 for e in q['lines']:
  l=e['patchline'];a,ao=l['source'];b,bi=l['destination'];assert a in bs and b in bs
  assert ao<bs[a]['numoutlets'] and bi<bs[b]['numinlets'],(a,ao,b,bi)
 for b in bs.values():
  if 'patcher'in b:validate(b['patcher'])
for d in docs.values():validate(d['patcher'])
oldpars=original[NAMES[2]]['patcher']['parameters']
for k,v in oldpars.items():
 if k=='parameter_overrides':
  assert all(device['parameters'][k][a]==b for a,b in v.items())
 else:assert device['parameters'][k]==v
assert sum(isinstance(v,list) for v in device['parameters'].values())==sum(isinstance(v,list) for v in oldpars.values())+4
assert boxes(main)['c2level']==boxes(original[NAMES[0]]['patcher'])['c2level']
assert boxes(main)['c3level']==boxes(original[NAMES[0]]['patcher'])['c3level']
assert boxes(main)['shift-mix-audio']['patcher']==boxes(shadow)['shift-mix-audio']['patcher']
# Exercise independently moving Up/Down curves and pans, including zero, mid and full blend.
for x in [0.,.25,.5,.75,1.]:
 for gu,gd,pu,pd in [(0.,.46,-1.,1.),(.72,0.,0.,.3),(.18,.39,-.7,.9),(0.,0.,0.,0.)]:
  U,D,N=.31,-.17,.23
  panu=[math.cos((pu+1)*math.pi/4),math.sin((pu+1)*math.pi/4)]
  pand=[math.cos((pd+1)*math.pi/4),math.sin((pd+1)*math.pi/4)]
  actual=[gu*panu[s]*((1-x)*U+x*N)+gd*pand[s]*((1-x)*D+x*N) for s in range(2)]
  expected=[(1-x)*(gu*panu[s]*U+gd*pand[s]*D)+x*N*(gu*panu[s]+gd*pand[s]) for s in range(2)]
  assert all(abs(a-b)<1e-12 for a,b in zip(actual,expected))
  if x==1.:assert all(abs(actual[s]-N*(gu*panu[s]+gd*pand[s]))<1e-12 for s in range(2))
OUT=Path('work/shift_mix_prepared');OUT.mkdir(exist_ok=True)
newraw={}
for n,d in docs.items():
 payload=json.dumps(d,ensure_ascii=False,indent=4).encode()
 if n.endswith('.amxd'):
  payload+=b'\0';h=bytearray(raw[n][:32]);h[28:32]=struct.pack('<I',len(payload));payload=bytes(h)+payload
 newraw[n]=payload;(OUT/n).write_bytes(payload);assert decode(n,payload)==d
manifest={n:hashlib.sha256(b).hexdigest() for n,b in raw.items()}
print('Prepared three files. Graphs, old parameter identities, shadow control, independent faders, and crossfade endpoint/automation math validated.')
print('New parameters: D1–D4 Shift-Mix. Default 0%; 100% unshifted; linear blend, 30-ms smoothing.')
if '--apply' in sys.argv:
 # Re-read before writing so an externally saved patch is never overwritten silently.
 assert all((R/n).read_bytes()==raw[n] for n in NAMES)
 backup=Path('work')/('shift_mix_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
 for n,b in raw.items():(backup/n).write_bytes(b)
 (backup/'sha256.json').write_text(json.dumps(manifest,indent=2))
 for n,b in newraw.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Applied; originals backed up in',backup.resolve())
