from pathlib import Path
import json,copy,struct,datetime,sys
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
ns=['Bpatcherdelayelement_M4l_update.maxpat','MS_4Inputs_Pan_Mix.maxpat','MS_MatrixreceiveShadows.maxpat','Freqshiftdelays_m4l.amxd'];raw={n:(R/n).read_bytes() for n in ns}
def decode(n,b):return json.JSONDecoder().raw_decode(b[32:].decode())[0] if n.endswith('.amxd') else json.loads(b)
ds={n:decode(n,b) for n,b in raw.items()};old=copy.deepcopy(ds)
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def initial(q,id,value):
 v=bs(q)[id].setdefault('saved_attribute_attributes',{}).setdefault('valueof',{})
 assert value>=v.get('parameter_mmin',0) and value<=v.get('parameter_mmax',1),(id,value,v)
 v['parameter_initial']=[value];v['parameter_initial_enable']=1
controls={'obj-813':0,'obj-17':0,'input-fade':1.,'obj-31':0,'obj-53':1,'obj-15':0.,'up':50.,'down':50.,'obj-66':4000.,'obj-67':.5}
q=ds[ns[0]]['patcher']
for id,value in controls.items():initial(q,id,value)
assert bs(q)['obj-813']['saved_attribute_attributes']['valueof']['parameter_enum'][0]=='No Input'
assert bs(q)['obj-17']['saved_attribute_attributes']['valueof']['parameter_enum'][0]=='Alle Aus'
assert bs(q)['obj-53']['saved_attribute_attributes']['valueof']['parameter_enum'][1]=='Linked'
m=ds[ns[1]]['patcher'];mixvalues={**{f'c{i}level':0. for i in range(4)},'c0pan':-100.,'c1pan':100.,'c2pan':0.,'c3pan':0.,'shift-mix':0.,'delay-mix':0.}
for id,value in mixvalues.items():initial(m,id,value)
# The ramps start in the same state as the new UI defaults in both banks.
for n in ns[1:3]:
 q=ds[n]['patcher']
 for id in ['shift-mix-audio','delay-mix-audio']:
  bs(bs(q)[id]['patcher'])['ramp']['text']='line~ 0.'
d=ds[ns[3]]['patcher'];parent=next(z['box']['patcher'] for z in d['boxes'] if z['box']['id']=='obj-4')
master={'obj-271':1000.,'obj-101':2.,'obj-102':3.,'obj-104':4.,'obj-4':0.,'obj-5':0.,'obj-6':0.,'obj-7':0.}
for id,value in master.items():initial(parent,id,value)
# Current per-instance overrides must not supersede the shared defaults.
for key,v in d['parameters'].get('parameter_overrides',{}).items():
 if key.startswith('obj-4::'):
  id=key.split('::')[-1]
  relevant=controls if key.split('::')[1] in ['obj-138','obj-139','obj-140','obj-142'] else mixvalues if key.split('::')[1] in ['obj-80','obj-81','obj-82','obj-83'] else {}
  if id in relevant:
   for field in ['parameter_initial','parameter_initial_enable']:v.pop(field,None)
# Validate requested exact values and ensure only initial attributes and DSP ramp initial constants changed.
def compare(a,b,path=''):
 if a==b:return
 if isinstance(a,dict) and isinstance(b,dict):
  for k in set(a)|set(b):
   if k in ['parameter_initial','parameter_initial_enable']:continue
   assert k in a and k in b,(path,k)
   compare(a[k],b[k],path+'/'+k)
 elif isinstance(a,list) and isinstance(b,list):
  assert len(a)==len(b),path
  for i,(aa,bb) in enumerate(zip(a,b)):compare(aa,bb,path+'/'+str(i))
 else:
  assert path.endswith('/text') and a=='line~ 1.' and b=='line~ 0.',(path,a,b)
for n in ns:compare(old[n],ds[n])
for id,value in controls.items():assert bs(ds[ns[0]]['patcher'])[id]['saved_attribute_attributes']['valueof']['parameter_initial']==[value]
for id,value in mixvalues.items():assert bs(m)[id]['saved_attribute_attributes']['valueof']['parameter_initial']==[value]
for id,value in master.items():assert bs(parent)[id]['saved_attribute_attributes']['valueof']['parameter_initial']==[value]
new={};out=Path('work/device_initial_defaults_prepared');out.mkdir(exist_ok=True)
for n,doc in ds.items():
 payload=json.dumps(doc,ensure_ascii=False,indent=4).encode()
 if n.endswith('.amxd'):
  payload+=b'\0';h=bytearray(raw[n][:32]);h[28:32]=struct.pack('<I',len(payload));payload=bytes(h)+payload
 assert decode(n,payload)==doc;new[n]=payload;(out/n).write_bytes(payload)
print('Validated all requested defaults, shared by four instances. No wiring, parameter identities, labels, ranges or automation changed. Main/shadow ramps start at0. D1–D4 times derive from1000ms * [1,2,3,4].')
if '--apply'in sys.argv:
 assert all((R/n).read_bytes()==raw[n] for n in ns)
 backup=Path('work')/('initial_defaults_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
 for n,b in raw.items():(backup/n).write_bytes(b)
 for n,b in new.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Saved and read back. Backup:',backup.resolve())
