from pathlib import Path
import json,copy,struct,datetime,sys,heapq,itertools
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
ns=['Freqshiftdelays_m4l.amxd','Freqshiftdelays_m4l_Init234.amxd'];raw={n:(R/n).read_bytes() for n in ns}
def decode(b):return json.JSONDecoder().raw_decode(b[32:].decode())[0]
ds={n:decode(b) for n,b in raw.items()};old=copy.deepcopy(ds)
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def edge(q,a,ao,b,bi):q['lines'].append({'patchline':{'source':[a,ao],'destination':[b,bi]}})
def rem(q,a,ao,b,bi):
 es=[e for e in q['lines'] if e['patchline']['source']==[a,ao] and e['patchline']['destination']==[b,bi]];assert len(es)==1,(a,b);q['lines'].remove(es[0])
def add(q,id,text,x,y,w,ni,no,types=None,**kw):
 assert id not in bs(q)
 b=dict(id=id,maxclass=kw.pop('maxclass','newobj'),text=text,patching_rect=[x,y,w,22.],numinlets=ni,numoutlets=no,**kw)
 if types is not None:b['outlettype']=types
 q['boxes'].append({'box':b});return b
matrices=['obj-117','obj-124','obj-134','obj-146']
for n,d in ds.items():
 root=d['patcher'];q=next(z['box']['patcher'] for z in root['boxes'] if z['box']['id']=='obj-4');b=bs(q)
 assert 'timechange-fade'not in b
 knob=copy.deepcopy(b['obj-104']);knob.update(id='timechange-fade',varname='ZeitwechselFadeSekunden',patching_rect=[1650.,100.,90.,25.],presentation_rect=[1338.,123.,90.,25.],hint='Musikalische Rückblende von alter Schattenzeit zu neuer Hauptzeit in Sekunden. Schattenzeiten werden erst am Fade-Ende nachgeführt. Beginn weiterhin 650 ms nach Trigger.')
 knob['saved_attribute_attributes']['valueof']={'parameter_initial':[1.],'parameter_initial_enable':1,'parameter_longname':'Zeitwechsel-Fade s','parameter_shortname':'Zeitwechsel-Fade','parameter_mmin':.1,'parameter_mmax':30.,'parameter_modmode':0,'parameter_type':0,'parameter_unitstyle':1}
 q['boxes'].append({'box':knob})
 add(q,'timefade-label','Zeitwechsel-Fade',1650.,65.,160.,1,0, maxclass='comment',presentation=1,presentation_rect=[1338.,96.,160.,20.],fontsize=12.)
 add(q,'timefade-unit','s',1750.,100.,25.,1,0,maxclass='comment',presentation=1,presentation_rect=[1434.,127.,25.,20.],fontsize=12.)
 add(q,'timefade-ms','* 1000.',1650.,145.,90.,2,1,['float'])
 add(q,'timefade-store','f 1000.',1650.,185.,90.,2,1,['float'])
 add(q,'timefade-values','t f f',1650.,225.,70.,1,2,['float','float'])
 add(q,'timefade-ramp','prepend ramp',1650.,265.,120.,1,1,[''])
 add(q,'timefade-return','t b b b',1440.,270.,90.,1,3,['bang']*3)
 add(q,'timefade-protect','t b b',1050.,65.,70.,1,2,['bang']*2)
 add(q,'timefade-protect100','100.',1150.,65.,55.,2,1,[''],maxclass='message')
 # Number edits only update the cold storage inlet; active fades keep their duration.
 edge(q,'timechange-fade',0,'timefade-ms',0);edge(q,'timefade-ms',0,'timefade-store',1)
 edge(q,'timefade-store',0,'timefade-values',0)
 edge(q,'timefade-values',1,'obj-556',1);edge(q,'timefade-values',0,'timefade-ramp',0)
 for id in matrices:edge(q,'timefade-ramp',0,id,0)
 # Keep the first handover at100ms and all existing main-time programming untouched.
 rem(q,'obj-113',1,'direct-shadow-select',0)
 edge(q,'obj-113',1,'timefade-protect',0)
 edge(q,'timefade-protect',1,'timefade-protect100',0);edge(q,'timefade-protect100',0,'timefade-ramp',0)
 edge(q,'timefade-protect',0,'direct-shadow-select',0)
 # Return still starts at100+550ms. Set duration first, select main second, start reset timer last.
 rem(q,'obj-544',0,'obj-528',0);rem(q,'obj-537',0,'obj-556',0)
 edge(q,'obj-544',0,'timefade-return',0)
 edge(q,'timefade-return',2,'timefade-store',0);edge(q,'timefade-return',1,'obj-528',0);edge(q,'timefade-return',0,'obj-556',0)
 b['obj-556']['text']='delay 1000';b['obj-556']['patching_rect'][2]=85.
 # Recall only the new control's stored value, never its initial value, after device initialization.
 add(q,'timefade-ready','live.thisdevice',1650.,320.,110.,1,3,['bang','int','int'])
 add(q,'timefade-defer','deferlow',1650.,360.,90.,1,1,[''])
 edge(q,'timefade-ready',0,'timefade-defer',0);edge(q,'timefade-defer',0,'timechange-fade',0)
 key='obj-4::timechange-fade';root['parameters'][key]=['Zeitwechsel-Fade s','Zeitwechsel-Fade',0]
 # Update stale timing comments only.
 b['obj-110']['text']='Rückblende zur Hauptbank ab 650 ms; Dauer: Zeitwechsel-Fade.'
 b['obj-111']['text']='Schattenzeiten erst nach Ende der Rückblende nachführen.'
 shadow=b['obj-33']['patcher'];bs(shadow)['obj-489']['text']='ZEITWECHSEL Schritt1: 0–100 ms alte Schattenbank übernehmen; ab100 ms Hauptzeiten setzen; ab650 ms einstellbare Rückblende. Schattenzeiten erst bei650 ms + Fade nachführen. Weitere Timing-Sicherheit unverändert.'
 # Confirm existing parameter metadata is identical and audio wiring was not touched.
 prior=old[n]['patcher']['parameters']
 for k,v in prior.items():assert root['parameters'][k]==v
 for id in ['obj-115','obj-544','obj-537','obj-195','obj-566','midi-trigger-once','midi-trigger-delay','midi-trigger-reset-order','obj-271','obj-101','obj-102','obj-104']:
  oq=next(z['box']['patcher'] for z in old[n]['patcher']['boxes'] if z['box']['id']=='obj-4');assert bs(q)[id]==bs(oq)[id]
 def validate(p):
  bb=bs(p);assert len(bb)==len(p['boxes'])
  for e in p['lines']:
   a,ao=e['patchline']['source'];c,ci=e['patchline']['destination'];assert a in bb and c in bb and ao<bb[a]['numoutlets'] and ci<bb[c]['numinlets'],(a,ao,c,ci)
  for ob in bb.values():
   if 'patcher'in ob:validate(ob['patcher'])
 validate(root)
 # Simulate the actual patched timing/control graph, using Max's right-to-left trigger ordering.
 for seconds in [.1,1.,3.,30.]:
  links={}
  for e in q['lines']:
   l=e['patchline'];links.setdefault(tuple(l['source']),[]).append(tuple(l['destination']))
  st={'timefade-store':1000.,'obj-115':100.,'obj-544':550.,'obj-556':1000.};events=[];counter=itertools.count();trace=[];now=[0.]
  def emit(id,port,v):
   for dest,inp in links.get((id,port),[]):receive(dest,inp,v)
  def receive(id,inp,v):
   text=bs(q)[id].get('text','')
   if id in ['direct-shadow-select','obj-528','obj-568','obj-195','obj-566']:
    trace.append((now[0],id,v));return
   if id in matrices:
    if isinstance(v,tuple) and v[0]=='ramp':trace.append((now[0],id,v[1]))
    return
   if id in ['timefade-ms']:emit(id,0,v*1000.);return
   if id in ['timefade-store']:
    if inp==1:st[id]=v
    else:emit(id,0,st[id] if v=='bang' else v)
    return
   if id in ['obj-115','obj-544','obj-556']:
    if inp==1:st[id]=v
    elif v=='bang':heapq.heappush(events,(now[0]+st[id],next(counter),id))
    return
   if id=='timefade-ramp':emit(id,0,('ramp',v));return
   if id=='timefade-protect100':emit(id,0,100.);return
   if text.startswith('t '):
    args=text.split()[1:]
    for port in range(len(args)-1,-1,-1):emit(id,port,'bang' if args[port]=='b' else v)
  receive('timefade-ms',0,seconds)
  receive('obj-113',0,'bang')
  while events:
   now[0],_,id=heapq.heappop(events);emit(id,0,'bang')
  for id,t in [('direct-shadow-select',0.),('obj-195',100.),('obj-566',100.),('obj-528',650.),('obj-568',650.+seconds*1000.)]:
   assert [a for a,b,v in trace if b==id]==[t],(n,seconds,id,trace)
  for id in matrices:assert [(t,v) for t,b,v in trace if b==id]==[(0.,100.),(650.,seconds*1000.)]
  assert len([1 for t,id,v in trace if id=='obj-568'])==1
 print(n,'validated timings for fade0.1/1/3/30s, first handover100ms, return650ms, reset650ms+fade; existing parameters and MIDI logic unchanged.')
out=Path('work/timefade_prepared');out.mkdir(exist_ok=True);new={}
for n,d in ds.items():
 payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';h=bytearray(raw[n][:32]);h[28:32]=struct.pack('<I',len(payload));new[n]=bytes(h)+payload;assert decode(new[n])==d;(out/n).write_bytes(new[n])
if '--apply'in sys.argv:
 assert all((R/n).read_bytes()==raw[n] for n in ns)
 back=Path('work')/('timefade_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));back.mkdir()
 for n,b in raw.items():(back/n).write_bytes(b)
 for n,b in new.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Saved with readback. Backup:',back.resolve())
