from pathlib import Path
import json,copy,datetime,sys,math
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
ns=['MS_4Inputs_Pan_Mix.maxpat','MS_MatrixreceiveShadows.maxpat'];raw={n:(R/n).read_bytes() for n in ns};ds={n:json.loads(b) for n,b in raw.items()};old=copy.deepcopy(ds)
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def edge(q,a,ao,b,bi):q['lines'].append({'patchline':{'source':[a,ao],'destination':[b,bi]}})
for n,doc in ds.items():
 q=doc['patcher'];h=bs(q)['delay-mix-audio']['patcher'];b=bs(h)
 assert 'gain3'in b and 'dry-shared'not in b
 # The direct signal is tapped before its independent channel fader.
 h['boxes']=[z for z in h['boxes'] if z['box']['id']!='gain3']
 h['lines']=[e for e in h['lines'] if 'gain3'not in [e['patchline']['source'][0],e['patchline']['destination'][0]] and e['patchline']['source'][0] not in ['gain0','gain1','gain2']]
 h['boxes'].append({'box':{'id':'dry-shared','maxclass':'newobj','text':'*~','numinlets':2,'numoutlets':1,'outlettype':['signal'],'patching_rect':[570.,290.,60.,22.]}})
 edge(h,'in3',0,'dry-shared',0);edge(h,'inverse',0,'dry-shared',1)
 for i in range(3):
  h['boxes'].append({'box':{'id':f'blend{i}','maxclass':'newobj','text':'+~','numinlets':2,'numoutlets':1,'outlettype':['signal'],'patching_rect':[30.+i*180.,360.,60.,22.]}})
  bs(h)[f'out{i}']['patching_rect'][1]=420.
  edge(h,f'gain{i}',0,f'blend{i}',0);edge(h,'dry-shared',0,f'blend{i}',1);edge(h,f'blend{i}',0,f'out{i}',0)
 edge(h,'in3',0,'out3',0)
 bs(h)['doc']['text']='Je Delayzweig: x*Delay + (1-x)*Original, danach vorhandener Pegel/Pan. Original folgt so den drei Delay-Hüllkurven. Separater Mikrofon-Fader bleibt unabhängig; 30 ms geglättet.'
 bs(h)['doc']['patching_rect']=[30.,470.,850.,60.];h['rect'][3]=570.
 bs(h)['in3']['comment']='Original vor unabhängigem Mikrofon-Fader'
 if n==ns[0]:
  bs(q)['delay-mix']['hint']='0 % Original innerhalb der drei Delayzweige; 100 % Delay-Mix. Beide folgen denselben Delay-Pegeln und Panoramen. Mikrofon direkt ist unabhängig und darf auf null stehen.'
  bs(q)['technical']['text']='Shift-Mix vor Up/Down-Pegel. Delay-Mix ersetzt jeden Delayzweig anteilig durch Original vor dessen Pegel/Pan. Separater Mikrofon-Fader unabhängig. Ausgang 3 steuert Schatten.'
 else:bs(q)['note']['text']='Schatten-Audio: gleiche Shift-/Delay-Überblendung vor den drei Delay-Pegeln und Panoramen. Original folgt deren Hüllkurven. Separater Mikrofon-Fader unabhängig; Steuerwerte vom Hauptmixer.'
# Validate actual patched steady-state signal graph rather than only the intended formula.
def eval_graph(q,inputs):
 b=bs(q);incoming={}
 for e in q['lines']:
  l=e['patchline'];incoming.setdefault(tuple(l['destination']),[]).append(tuple(l['source']))
 memo={}
 def output(id,port=0):
  if (id,port) in memo:return memo[id,port]
  obj=b[id];text=obj.get('text','')
  def inlet(i):
   src=incoming.get((id,i),[]);return sum(output(a,p) for a,p in src) if src else 0.
  if obj['maxclass']=='inlet':v=inputs[id]
  elif text=='clip 0. 1.':v=min(1.,max(0.,inlet(0)))
  elif text in ['pack 0. 30','line~ 1.']:v=inlet(0)
  elif text=='!-~ 1.':v=1.-inlet(0)
  elif text=='*~':v=inlet(0)*inlet(1)
  elif text=='+~' or obj['maxclass']=='outlet':v=inlet(0)
  else:raise AssertionError((id,text))
  if text=='+~':v+=inlet(1)
  memo[id,port]=v;return v
 return [output(f'out{i}') for i in range(4)]
for n,doc in ds.items():
 q=doc['patcher'];h=bs(q)['delay-mix-audio']['patcher']
 for x in [0.,.25,.5,.75,1.]:
  for signals in [[.31,-.17,.23,.4],[0.,0.,.23,.4]]:
   got=eval_graph(h,{**{f'in{i}':v for i,v in enumerate(signals)},'in4':x})
   expected=[x*v+(1-x)*signals[3] for v in signals[:3]]+[signals[3]]
   assert all(abs(a-b)<1e-12 for a,b in zip(got,expected))
   # Zero independent microphone fader: direct still follows active delay levels and pans.
   for levels in [[.72,0.,0.,0.],[.18,.39,0.,0.],[0.,0.,.7,0.]]:
    for trig in [math.cos,math.sin]:
     pans=[-.8,.7,0.,-.2];g=[v*trig((p+1)*math.pi/4) for v,p in zip(levels,pans)]
     actual=sum(v*a for v,a in zip(got,g));exp=x*sum(v*a for v,a in zip(signals[:3],g[:3]))+(1-x)*signals[3]*sum(g[:3])+signals[3]*g[3]
     assert abs(actual-exp)<1e-12
     if x==0:assert abs(actual)>0.
 oldq=old[n]['patcher'];assert q['lines']==oldq['lines']
 for id,b in bs(oldq).items():
  if id not in ['delay-mix-audio','delay-mix','technical','note']:assert bs(q)[id]==b
 def validate(p):
  bb=bs(p);assert len(bb)==len(p['boxes'])
  for e in p['lines']:
   a,ao=e['patchline']['source'];c,ci=e['patchline']['destination'];assert a in bb and c in bb and ao<bb[a]['numoutlets'] and ci<bb[c]['numinlets']
  for obj in bb.values():
   if 'patcher'in obj:validate(obj['patcher'])
 validate(q)
new={n:json.dumps(d,ensure_ascii=False,indent=4).encode() for n,d in ds.items()}
out=Path('work/delay_mix_coupling_prepared');out.mkdir(exist_ok=True)
for n,b in new.items():(out/n).write_bytes(b);assert json.loads(b)==ds[n]
print('Validated actual signal graphs: endpoints and intermediate blends, independent mic fader zero, moving Up/Down and plain delay levels/pans, identical main/shadow behavior; existing wiring and parameter identities preserved.')
if '--apply'in sys.argv:
 assert all((R/n).read_bytes()==raw[n] for n in ns)
 backup=Path('work')/('delay_mix_coupling_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
 for n,b in raw.items():(backup/n).write_bytes(b)
 for n,b in new.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Applied with readback; backup:',backup.resolve())
