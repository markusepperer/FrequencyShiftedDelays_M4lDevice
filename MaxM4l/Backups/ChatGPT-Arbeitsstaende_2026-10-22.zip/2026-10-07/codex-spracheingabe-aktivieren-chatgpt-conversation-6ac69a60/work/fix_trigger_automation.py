from pathlib import Path
import json,copy,struct,hashlib,datetime
P=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/Freqshiftdelays_m4l.amxd');raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d)
q=next(x['box']['patcher'] for x in d['patcher']['boxes'] if x['box']['id']=='obj-4');b={x['box']['id']:x['box'] for x in q['boxes']}
remove={'midi-trigger-zero','midi-trigger-reset-order'}
q['boxes']=[x for x in q['boxes'] if x['box']['id'] not in remove]
q['lines']=[x for x in q['lines'] if x['patchline']['source'][0] not in remove and x['patchline']['destination'][0] not in remove]
q['lines'].append({'patchline':{'source':['midi-trigger-delay',0],'destination':['midi-trigger-once',1]}})
b['obj-2']['transition']=0
b['obj-2']['hint']='Delayzeiten übernehmen: Bang bei Off → On. Kein automatisches Zurückschreiben. Automation: On/Off-Puls; MIDI: CC-Taster, Momentary, Drücken 127 / Loslassen 0.'
c=b['timefade-doc-midi-trigger-reset-order'];c['text']='50 ms: nur interne onebang-Sperre freigeben.\nKein set 0 an den automatisierten Parameter.';c['linecount']=2
h=b['timechange-lock']['patcher']
for x in h['boxes']:
 if x['box']['id']=='doc-midi':x['box'].update(text='50 ms entprellen nur den internen Trigger (onebang); der Live-Parameter wird nicht zurückgeschrieben.\nOff kommt aus der Automation oder vom Loslassen des MIDI-CC-Tasters (Momentary: 127 / 0).',linecount=2)
assert not any(x['patchline']['destination'][0]=='obj-2' for x in q['lines'])
assert d['patcher']['parameters']==old['patcher']['parameters']
for x in q['boxes']:
 before=next(y['box'] for y in next(z['box']['patcher'] for z in old['patcher']['boxes'] if z['box']['id']=='obj-4')['boxes'] if y['box']['id']==x['box']['id'])
 assert x['box'].get('patching_rect')==before.get('patching_rect')
# Both automation pulses and momentary CC map to identical rising/falling parameter edges.
for values in ([0,1,1,0,0,1,0],[0,127,127,0,0,127,0]):
 prev=0;bangs=0
 for v in values:
  state=int(v>0);bangs+=state==1 and prev==0;prev=state
 assert bangs==2
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';header=bytearray(raw[:32]);header[28:32]=struct.pack('<I',len(payload));Path('work/trigger_automation.prepared.amxd').write_bytes(bytes(header)+payload)
stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');m={'device':str(P),'backup':str(P.parent/'Backups'/('vor_Trigger_Automation_'+stamp)),'protocol':str(P.parent/('Protokoll_Trigger_Automation_'+stamp+'.md')),'hash':hashlib.sha256(raw).hexdigest()};Path('work/trigger_automation_manifest.json').write_text(json.dumps(m));print(json.dumps(m))
