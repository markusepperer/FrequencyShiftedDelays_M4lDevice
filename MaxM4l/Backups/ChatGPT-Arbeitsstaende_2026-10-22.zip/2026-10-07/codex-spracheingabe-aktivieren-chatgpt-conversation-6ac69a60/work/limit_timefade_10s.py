from pathlib import Path
import json,copy,struct,datetime,sys
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
ns=['Freqshiftdelays_m4l.amxd','Freqshiftdelays_m4l_Init234.amxd'];raw={n:(R/n).read_bytes() for n in ns};new={}
for n,b in raw.items():
 d=json.JSONDecoder().raw_decode(b[32:].decode())[0];original=copy.deepcopy(d)
 q=next(z['box']['patcher'] for z in d['patcher']['boxes'] if z['box']['id']=='obj-4')
 box=next(z['box'] for z in q['boxes'] if z['box']['id']=='timechange-fade')
 v=box['saved_attribute_attributes']['valueof'];assert v['parameter_mmax']==30.;v['parameter_mmax']=10.
 check=copy.deepcopy(d);cq=next(z['box']['patcher'] for z in check['patcher']['boxes'] if z['box']['id']=='obj-4');next(z['box'] for z in cq['boxes'] if z['box']['id']=='timechange-fade')['saved_attribute_attributes']['valueof']['parameter_mmax']=30.;assert check==original
 payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';h=bytearray(b[:32]);h[28:32]=struct.pack('<I',len(payload));new[n]=bytes(h)+payload
 assert json.JSONDecoder().raw_decode(new[n][32:].decode())[0]==d
print('Both files prepared: only parameter maximum30→10seconds; default1second unchanged.')
if '--apply'in sys.argv:
 assert all((R/n).read_bytes()==b for n,b in raw.items())
 backup=Path('work')/('timefade_10s_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
 for n,b in raw.items():(backup/n).write_bytes(b)
 for n,b in new.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Saved and read back; backup:',backup.resolve())
