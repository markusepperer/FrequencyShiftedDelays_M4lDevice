from pathlib import Path
import json,copy,struct,hashlib,datetime
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l'); P=R/'Freqshiftdelays_m4l.amxd'
raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d)
def boxes(q):return {x['box']['id']:x['box'] for x in q['boxes']}
q=boxes(d['patcher'])['obj-4']['patcher']; b=boxes(q)
def note(o,text):
 o.update(text=text,fontsize=10.,textcolor=[.22,.22,.22,1.],bgcolor=[.88,.88,.88,1.]);o['linecount']=text.count('\n')+1
note(b['timefade-doc-timefade-ms'],'Sekunden × 1000 = Fade-Dauer in Millisekunden.')
note(b['timefade-doc-timefade-store'],'Dauer rechts speichern; bei Rückblendenbeginn links abrufen.')
note(b['timefade-doc-timefade-values'],'Rechts: Dauer an Timer. Links: dieselbe Dauer an Audio-Fade.')
note(b['timefade-doc-timefade-return'],'4: Rechts Dauer holen; Mitte Hauptbank einblenden.\nLinks Fade-Endtimer starten (nach 650 ms Vorlauf).')
b['timefade-doc-timefade-return']['patching_rect']=[477.,44.6,245.,40.]
b['timefade-doc-timefade-return']['fontsize']=9.
note(b['timefade-doc-obj-556'],'FADE-ENDTIMER: rechts Dauer (ms), links Start-Bang.\nNach Ablauf: Schatten nachführen + Sperre-Eingang 2 melden.')
b['timefade-doc-obj-556']['patching_rect']=[410.,214.,510.,29.]
note(b['timechange-lock-note'],'Trigger sperrt sofort.\nEingang 2: Fade-Ende.\nDoppelklick für Freigabe.')
h=b['timechange-lock']['patcher'];hb=boxes(h)
for x in hb.values():
 if x['maxclass']=='comment':note(x,x['text'])
note(hb['doc-complete'],'5: Bang vom Fade-Endtimer im Hauptpatch (delay 1000).\nDessen rechter Eingang erhält die gewählte Fade-Dauer.\nErst Schattenzeiten senden, dann diesen Eingang auslösen.\nDarum braucht die Sperre kein eigenes Fade-Zeit-Kabel.')
note(hb['doc-release'],'6: Nach dem Fade-Ende noch 100 ms warten:\n50 ms Schatten-Zeitrampen + 50 ms Sicherheitsabstand.\nDann öffnet die Nachricht 1 das Gate für neue Trigger.')
note(hb['doc-time'],'ABLAUF: Trigger sperrt → 650 ms Vorlauf → eingestellter Fade → Schattenzeiten nachführen → 100 ms → freigeben.\nBei 3 s Fade: Timer startet bei 0,65 s; Ende bei 3,65 s; Gate wieder offen bei 3,75 s.\nDie Sperre wartet auf das Fade-Endereignis. Ein längerer Fade verschiebt automatisch auch die Freigabe.')
for id,num,rect in [('doc-step-5','5',[480.,55.,20.,20.]),('doc-step-6','6',[480.,160.,20.,20.])]:
 badge=copy.deepcopy(b['obj-112']);badge.update(id=id,text=num,patching_rect=rect);h['boxes'].append({'box':badge})
# Correct the obsolete explanation that still says the trigger lock is missing.
process=boxes(b['obj-137']['patcher'])['obj-136']
process['text']=process['text'].replace('Und bis wir die vollständige Triggersperre ergänzen, solltest du den nächsten Zeitwechsel erst auslösen, wenn dieser Ablauf beendet ist.','Die Triggersperre schließt sofort beim Start. Der Fade-Endtimer führt nach der Rückblende die Schattenzeiten nach und meldet sein Ende an Eingang 2 von p Zeitwechsel-Sperre. Dort wartet delay 100 weitere 100 ms und gibt dann frei. Bei 3 s Fade ist der nächste Wechsel nach 3,75 s möglich. Trigger während der Sperre werden verworfen.')
process.update(fontsize=10.,textcolor=[.22,.22,.22,1.],bgcolor=[.88,.88,.88,1.],patching_rect=[50.,100.,700.,540.])
# Strip only documentation to prove the entire functional tree and wiring unchanged.
def functional(p):
 p=copy.deepcopy(p);p['boxes']=[x for x in p['boxes'] if x['box']['maxclass']!='comment' and not (x['box']['maxclass']=='textbutton' and x['box'].get('ignoreclick')==1)]
 for x in p['boxes']:
  if 'patcher' in x['box']:x['box']['patcher']=functional(x['box']['patcher'])
 return p
assert functional(d['patcher'])==functional(old['patcher'])
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';header=bytearray(raw[:32]);header[28:32]=struct.pack('<I',len(payload));new=bytes(header)+payload
stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');back=R/'Backups'/('vor_Fade_Sperre_Kommentare_'+stamp)
Path('work/comment_fade_lock.prepared.amxd').write_bytes(new)
m={'source_sha256':hashlib.sha256(raw).hexdigest(),'backup':str(back),'device':str(P),'protocol':str(R/('Protokoll_Fade_Sperre_Kommentare_'+stamp+'.md'))}
Path('work/comment_fade_lock_manifest.json').write_text(json.dumps(m));print(json.dumps(m))
