from pathlib import Path
import json,copy,struct,datetime,textwrap,sys
P=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/Freqshiftdelays_m4l.amxd')
raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d);q=next(z['box']['patcher'] for z in d['patcher']['boxes'] if z['box']['id']=='obj-4');b={z['box']['id']:z['box'] for z in q['boxes']}
# Dedicated readable explanation lane. Every object is paired with its comment on the same row.
rows=[
('timefade-ready',-280,'Live hat Parameter geladen: gespeicherte Fade-Dauer abfragen. Auch nach Presetwechsel.'),
('timefade-defer',-215,'Abfrage verzögern. Danach aktuellen Numberbox-Wert ausgeben; keine Rücksetzung auf den Startwert.'),
('timechange-fade',-150,'Fade-Dauer in Sekunden: 0,1–10 s. Bestimmt die lange Überblendung von alter Schattenzeit zur neuen Hauptzeit.'),
('timefade-ms',-85,'Sekunden × 1000 = Millisekunden für Matrix und Timer.'),
('timefade-store',-20,'Rechts: Dauer vormerken, ohne Ausgabe. Links: vorgemerkte Dauer beim Rückblendenbeginn ausgeben.'),
('obj-113',120,'Start: rechts zuerst Schatten-Übernahme; links danach die vorhandene 100-ms-Wartezeit starten.'),
('timefade-protect',185,'Rechts zuerst 100 ms an die Matrizen senden. Links danach die alte Schattenbank auswählen.'),
('timefade-protect100',250,'100 Millisekunden für die kurze Haupt→Schatten-Übernahme; unabhängig von der musikalischen Fade-Dauer.'),
('timefade-return',390,'Ab650 ms: rechts Dauer abrufen; Mitte Hauptbank einblenden; links Timer für Schatten-Nachführung starten.'),
('timefade-values',455,'Rechts zuerst Timerdauer setzen, links danach dieselbe Dauer an die Matrix-Rampen weitergeben.'),
('timefade-ramp',520,'Erzeugt „ramp <ms>“: Dauer der Lautstärkeüberblendung. Ändert keine Delay-Lesezeit.'),
('obj-39',585,'Verteilt ramp-Befehle an die vier Empfänger bei den Ausgangsmatrizen. --- trennt die Geräteinstanzen.'),
('obj-556',650,'Timer startet mit der Rückblende und wartet die gewählte Dauer. Erst danach Schattenzeiten nachführen.'),
('midi-trigger-reset-order',790,'Bestehende MIDI-Rücksetzung nach50 ms. Noch keine Sperre über den ganzen Fade; weitere Trigger erst nach650 ms + Fade.'),
]
X=2000.;CX=2280.;W=355.
for anchor,y,text in rows:
 ob=b[anchor];ob['patching_rect'][0]=X;ob['patching_rect'][1]=float(y)
 note=b['timefade-doc-'+anchor];lines=textwrap.wrap(text,55,break_long_words=False)
 note.update(text='\n'.join(lines),fontsize=11.,linecount=len(lines),patching_rect=[CX,float(y),W,16.*len(lines)+6.])
# Place the existing descriptive label/unit next to their relocated Numberbox only in patching view.
b['timefade-label']['patching_rect']=[X,-172.,180.,20.]
b['timefade-unit']['patching_rect']=[X+105.,-150.,20.,20.]
headings=[('init',-325.,'1 · DAUER LADEN UND VORMERKEN'),('protect',75.,'2 · ALTE SCHATTENBANK ÜBERNIMMT'),('return',345.,'3 · MUSIKALISCHER FADE UND NACHTRAGEN'),('midi',745.,'4 · BESTEHENDE MIDI-LOGIK – SCHRITT 2 NOCH OFFEN')]
for id,y,text in headings:
 q['boxes'].append({'box':{'id':'timefade-doc-heading-'+id,'maxclass':'comment','text':text,'fontsize':13.,'fontface':1,'numinlets':1,'numoutlets':0,'presentation':0,'patching_rect':[X,y,640.,24.]}})
# Receiver notes remain in the audio section, immediately to the right of their exact receive object.
for i,id in enumerate(['obj-132','obj-131','obj-122','obj-44'],1):
 x,y,w,h=b[id]['patching_rect'];note=b['timefade-doc-'+id]
 note.update(text=f'D{i}: Fade-Zeit für\ndie Matrix darunter.',fontsize=9.,linecount=2,patching_rect=[x+w+8.,y,128. if i>1 else 105.,28.])
# Old timing objects in new explanatory lane need no old elbow coordinates.
moved={id for id,_,_ in rows}|{'timefade-label','timefade-unit'}
for e in q['lines']:
 l=e['patchline']
 if l['source'][0]in moved or l['destination'][0]in moved:l.pop('midpoints',None)
# Verify the patch is identical after stripping only layout/comment changes.
def strip(q):
 q=copy.deepcopy(q)
 q['boxes']=[z for z in q['boxes'] if z['box']['maxclass']!='comment']
 for z in q['boxes']:
  ob=z['box'];ob.pop('patching_rect',None)
  if 'patcher'in ob:ob['patcher']=strip(ob['patcher'])
 for e in q['lines']:e['patchline'].pop('midpoints',None)
 return q
assert strip(d['patcher'])==strip(old['patcher'])
# Keep the Live presentation exactly as it was.
oq=next(z['box']['patcher'] for z in old['patcher']['boxes'] if z['box']['id']=='obj-4');ob={z['box']['id']:z['box'] for z in oq['boxes']}
for id,obj in ob.items():assert b[id].get('presentation_rect')==obj.get('presentation_rect')
# Each new explanatory row has its own horizontal slot and its original object on the same y.
for anchor,y,text in rows:
 assert b[anchor]['patching_rect'][1]==b['timefade-doc-'+anchor]['patching_rect'][1]
 assert b['timefade-doc-'+anchor]['patching_rect'][3]<65.
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';h=bytearray(raw[:32]);h[28:32]=struct.pack('<I',len(payload));new=bytes(h)+payload
assert json.JSONDecoder().raw_decode(new[32:].decode())[0]==d
Path('work/crossfade_comments_aligned.prepared.amxd').write_bytes(new)
print('Prepared clear object/comment rows and four local receiver captions. Verified identical functional patch and identical Live presentation.')
if '--apply'in sys.argv:
 assert P.read_bytes()==raw
 back=Path('work')/('Freqshiftdelays_m4l.before_comment_alignment_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.amxd');back.write_bytes(raw)
 P.write_bytes(new);assert P.read_bytes()==new
 print('Saved and read back; backup:',back.resolve())
