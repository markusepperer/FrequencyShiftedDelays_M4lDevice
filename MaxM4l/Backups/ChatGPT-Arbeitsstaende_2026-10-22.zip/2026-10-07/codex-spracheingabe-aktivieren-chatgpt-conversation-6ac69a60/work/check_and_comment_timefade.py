from pathlib import Path
import json,copy,struct,datetime,heapq,itertools,textwrap,sys
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l');p=R/'Freqshiftdelays_m4l.amxd';raw=p.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d)
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
q=next(z['box']['patcher'] for z in d['patcher']['boxes'] if z['box']['id']=='obj-4');b=bs(q)
base=json.JSONDecoder().raw_decode(Path('work/timefade_prepared/Freqshiftdelays_m4l.amxd').read_bytes()[32:].decode())[0]
baseq=next(z['box']['patcher'] for z in base['patcher']['boxes'] if z['box']['id']=='obj-4')
def edges(q):return {(tuple(e['patchline']['source']),tuple(e['patchline']['destination'])) for e in q['lines']}
matrices=['obj-117','obj-124','obj-134','obj-146'];sender='obj-39';receivers=['obj-132','obj-131','obj-122','obj-44']
# Prove wire replacement equivalence: collapse the new send/receive bus back into four virtual edges.
virtual=edges(q).copy();virtual.remove((('timefade-ramp',0),(sender,0)))
assert b[sender]['text']=='send dynamischerampe_fades'
for rec,mat in zip(receivers,matrices):
 assert b[rec]['text']=='receive dynamischerampe_fades'
 virtual.remove(((rec,0),(mat,0)));virtual.add((('timefade-ramp',0),(mat,0)))
assert virtual==edges(baseq),'Unexpected main-graph changes beyond the replaced wires'
for id in [sender,*receivers]:b[id]['text']=b[id]['text'].replace('dynamischerampe_fades','---dynamischerampe_fades')
# Do not widen existing objects or move the user's layout. The new symbol still fits by setting a compact font.
for id in [sender,*receivers]:b[id]['fontsize']=10.
# Simulate the current graph including synchronous send/receive dispatch and trigger ordering.
traces=[]
for seconds in [.1,1.,3.,10.]:
 links={}
 for e in q['lines']:
  l=e['patchline'];links.setdefault(tuple(l['source']),[]).append(tuple(l['destination']))
 state={'timefade-store':1000.,'obj-115':100.,'obj-544':550.,'obj-556':1000.};events=[];counter=itertools.count();trace=[];now=[0.]
 def emit(id,port,v):
  for dest,inp in links.get((id,port),[]):receive(dest,inp,v)
 def receive(id,inp,v):
  text=b[id].get('text','')
  if id in ['direct-shadow-select','obj-528','obj-568','obj-195','obj-566']:trace.append((now[0],id,v));return
  if id in matrices:
   if isinstance(v,tuple) and v[0]=='ramp':trace.append((now[0],id,v[1]))
   return
  if id==sender:
   for r in receivers:emit(r,0,v)
   return
  if id=='timefade-ms':emit(id,0,v*1000.);return
  if id=='timefade-store':
   if inp==1:state[id]=v
   else:emit(id,0,state[id] if v=='bang' else v)
   return
  if id in ['obj-115','obj-544','obj-556']:
   if inp==1:state[id]=v
   elif v=='bang':heapq.heappush(events,(now[0]+state[id],next(counter),id))
   return
  if id=='timefade-ramp':emit(id,0,('ramp',v));return
  if id=='timefade-protect100':emit(id,0,100.);return
  if text.startswith('t '):
   args=text.split()[1:]
   for port in range(len(args)-1,-1,-1):emit(id,port,'bang' if args[port]=='b' else v)
 receive('timefade-ms',0,seconds);receive('obj-113',0,'bang')
 while events:
  now[0],_,id=heapq.heappop(events);emit(id,0,'bang')
 for id,t in [('direct-shadow-select',0.),('obj-195',100.),('obj-566',100.),('obj-528',650.),('obj-568',650.+seconds*1000.)]:assert [a for a,z,v in trace if z==id]==[t],(seconds,id,trace)
 for id in matrices:assert [(t,v) for t,z,v in trace if z==id]==[(0.,100.),(650.,seconds*1000.)]
 traces.append({'fade_seconds':seconds,'return_ms':650,'shadow_update_ms':650+seconds*1000})
# Verify send/receive names in the full saved device and validate every local abstraction port.
docs={}
for f in R.glob('*.maxpat'):docs[f.name]=json.loads(f.read_text())
ports=[]
def validate(q,path=''):
 bb=bs(q);assert len(bb)==len(q['boxes'])
 for e in q['lines']:
  l=e['patchline']
  for id,port,key,cls in [(l['source'][0],l['source'][1],'numoutlets','outlet'),(l['destination'][0],l['destination'][1],'numinlets','inlet')]:
   assert id in bb
   ob=bb[id];count=ob[key];sub=ob.get('patcher');name=ob.get('name') if ob['maxclass']=='bpatcher' else ob.get('text','').split(' ')[0]+'.maxpat'
   if sub is None and name in docs:sub=docs[name]['patcher']
   if sub is not None:count=sum(z['box']['maxclass']==cls for z in sub['boxes'])
   assert port<count,(path,id,key,port,count)
 for id,ob in bb.items():
  if 'patcher'in ob:validate(ob['patcher'],path+'/'+id)
validate(d['patcher'])
# Add explanatory comments near each new functional object; presentation UI and all original coordinates stay intact.
notes=[
 ('timechange-fade','ZEITWECHSEL-FADE · Dauer in Sekunden (0,1–10; Startwert 1). Bestimmt nur die lange Rückblende: alte Schattenbank aus, neue Hauptbank ein.'),
 ('timefade-ready','INITIALISIERUNG 1 · live.thisdevice meldet, dass Live die Geräteparameter geladen hat. Auch beim Presetwechsel wird die Ausgabe angestoßen.'),
 ('timefade-defer','INITIALISIERUNG 2 · deferlow verschiebt die Abfrage nach hinten. Ein Bang an die Numberbox gibt ihren aktuellen Wert aus; es wird kein Default erzwungen.'),
 ('timefade-ms','EINHEITEN · * 1000. rechnet Sekunden in Millisekunden um. Die Matrix-Rampen und das delay-Objekt erwarten Millisekunden.'),
 ('timefade-store','DAUERSPEICHER · f 1000.: rechts aktuellen Millisekundenwert vormerken, ohne Ausgabe. Erst der Bang links beim Beginn der Rückblende liest ihn aus.'),
 ('timefade-values','DAUER VERTEILEN · t f f arbeitet rechts zuerst: Wartezeit am kalten Eingang von delay setzen; danach dieselbe Dauer als Matrix-Rampe senden.'),
 ('timefade-ramp','MATRIX-BEFEHL · prepend ramp erzeugt „ramp <Millisekunden>“. Ändert die Dauer folgender Pegelüberblendungen, nicht die Delay-Lesezeit.'),
 (sender,'VERTEILUNG · send ---dynamischerampe_fades ersetzt die vier langen Kabel. Sendet nur Steuerbefehle, kein Audio. --- trennt mehrere Live-Geräteinstanzen.'),
 ('timefade-protect','ERSTE UMSCHALTUNG · t b b: zuerst rechts die Matrix-Rampen auf 100 ms zurücksetzen, danach links die alte Schattenbank auswählen. Die lange Fade-Dauer gilt hier nicht.'),
 ('timefade-protect100','KURZER SCHUTZFADE · 100. bedeutet 100 Millisekunden für Haupt → Schatten. Wird vor jeder ersten Umschaltung erneut an alle Ausgangsmatrizen gesendet.'),
 ('timefade-return','MUSIKALISCHE RÜCKBLENDE · t b b b, rechts nach links: 1. Fade-Dauer abrufen und verteilen; 2. Hauptbank auswählen; 3. Timer für Schatten-Nachführung starten.'),
 ('obj-556','SCHATTEN SPÄTER NACHFÜHREN · delay 1000 bekommt rechts die gewählte Fade-Dauer. Der Bang links startet erst bei Rückblendenbeginn. Danach: reset-shadow-delaytimes. Alte Zeit bleibt während des Fades erhalten.'),
]
for i,(rec,mat) in enumerate(zip(receivers,matrices),1):notes.append((rec,f'FADE-EMPFÄNGER D{i} · Derselbe gerätespezifische ramp-Befehl geht an die Ausgangsmatrix darunter. Die Matrix überblendet Haupt-L/R gegen Schatten-L/R; die inneren Schatten-Delays benötigen keinen eigenen Fade-Parameter.'))
notes += [('obj-113','ABLAUF · Trigger: 0–100 ms Schatten übernehmen. Ab100 ms neue Hauptzeiten einstellen. Ab650 ms Rückblende über die gewählte Dauer. Schatten-Nachführung bei650 ms + Fade. Sicherheitsabstände und längere Triggersperre gehören zum noch offenen zweiten Schritt.'),('midi-trigger-reset-order','TRIGGER-HINWEIS · Die bestehende 50-ms-Logik setzt den MIDI-Button zurück und gibt ihn wieder frei. Sie sperrt noch NICHT den gesamten Zeitwechsel. Bis zum zweiten Schritt: nächsten Wechsel erst nach650 ms + Fade auslösen.')]
occupied=[z['box']['patching_rect'] for z in q['boxes']]
def overlaps(a,c,gap=9):return a[0]<c[0]+c[2]+gap and a[0]+a[2]+gap>c[0] and a[1]<c[1]+c[3]+gap and a[1]+a[3]+gap>c[1]
layout=[]
for anchor,text in notes:
 rect=b[anchor]['patching_rect'];w=290.;lines=[]
 for para in text.split('\n'):lines.extend(textwrap.wrap(para,width=44,break_long_words=False))
 h=17.*len(lines)+8.;candidates=[]
 for dy in range(-450,451,30):
  for dx in range(-600,901,50):
   x=rect[0]+rect[2]+18+dx;y=rect[1]+dy
   candidate=[round(x,1),round(y,1),w,h]
   if x<0:continue
   if not any(overlaps(candidate,a) for a in occupied):
    score=abs(dx)+abs(dy)*1.4+(70 if dx<0 else 0);candidates.append((score,candidate))
 if candidates:place=min(candidates,key=lambda x:x[0])[1]
 else:place=[2000.,-400.+len(layout)*160.,w,h]
 occupied.append(place);id='timefade-doc-'+anchor
 assert id not in bs(q)
 q['boxes'].append({'box':{'id':id,'maxclass':'comment','text':'\n'.join(lines),'numinlets':1,'numoutlets':0,'patching_rect':place,'fontsize':11.,'textcolor':[.12,.18,.24,1.],'presentation':0,'linecount':len(lines)}})
 layout.append({'anchor':anchor,'rect':place,'text':text})
# Check annotation rectangles don't cover any saved original object, including user's comments.
for item in layout:
 assert not any(overlaps(item['rect'],z['box']['patching_rect'],0) for z in old['patcher']['boxes'] if False)
oldq=next(z['box']['patcher'] for z in old['patcher']['boxes'] if z['box']['id']=='obj-4')
for item in layout:assert not any(overlaps(item['rect'],z['box']['patching_rect'],0) for z in oldq['boxes'])
# Preserve user's object coordinates, presentation layout, all wiring and every parameter entry.
assert q['lines']==oldq['lines'];assert d['patcher']['parameters']==old['patcher']['parameters']
for id,ob in bs(oldq).items():
 assert bs(q)[id]['patching_rect']==ob['patching_rect']
 assert bs(q)[id].get('presentation_rect')==ob.get('presentation_rect')
 if id not in [sender,*receivers]:assert bs(q)[id]==ob
validate(d['patcher'])
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';h=bytearray(raw[:32]);h[28:32]=struct.pack('<I',len(payload));new=bytes(h)+payload;assert json.JSONDecoder().raw_decode(new[32:].decode())[0]==d
Path('work/timefade_commented.prepared.amxd').write_bytes(new)
Path('work/timefade_comment_layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2))
print('Verified equivalent send/receive graph, 4 fade durations, actual local abstraction ports. Added',len(notes),'comments with no overlap of existing boxes. Only functional edit: per-device bus name. Existing user layout and all cables/parameters preserved.')
print('Timings:',traces)
if '--apply'in sys.argv:
 assert p.read_bytes()==raw
 backup=Path('work')/('Freqshiftdelays_m4l.before_crossfade_comments_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.amxd');backup.write_bytes(raw)
 p.write_bytes(new);assert p.read_bytes()==new;print('Saved and read back; backup:',backup.resolve())
