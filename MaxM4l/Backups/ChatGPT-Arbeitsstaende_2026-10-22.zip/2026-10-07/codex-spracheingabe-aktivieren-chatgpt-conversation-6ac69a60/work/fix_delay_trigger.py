from pathlib import Path
import json,struct,hashlib,sys,datetime
p=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/Freqshiftdelays_m4l.amxd')
raw=p.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0]
q=next(z['box']['patcher'] for z in d['patcher']['boxes'] if z['box']['id']=='obj-4')
bs={z['box']['id']:z['box'] for z in q['boxes']};assert bs['obj-2']['maxclass']=='live.button'
assert not any(k.startswith('midi-trigger-') for k in bs)
old={'patchline':{'destination':['obj-113',0],'source':['obj-2',0]}}
assert old in q['lines'];q['lines'].remove(old)
bs['obj-2']['transition']=0
bs['obj-2']['hint']='Delayzeiten übernehmen: ein Impuls pro Betätigung. MIDI-Parameter wird nach 50 ms still zurückgesetzt; Rücksetzung gegen erneutes Auslösen gesperrt.'
def box(id,text,x,y,ni,no,types,cls='newobj'):
 q['boxes'].append({'box':{'id':id,'maxclass':cls,'text':text,'patching_rect':[x,y,105.0,22.0],'numinlets':ni,'numoutlets':no,'outlettype':types}})
box('midi-trigger-once','onebang 1',450.,20.,2,1,['bang'])
box('midi-trigger-fanout','t b b',450.,55.,1,2,['bang','bang'])
box('midi-trigger-delay','delay 50',570.,90.,2,1,['bang'])
box('midi-trigger-reset-order','t b b',570.,125.,1,2,['bang','bang'])
box('midi-trigger-zero','set 0',690.,160.,2,1,[''],'message')
def edge(a,ao,b,bi):q['lines'].append({'patchline':{'source':[a,ao],'destination':[b,bi]}})
edge('obj-2',0,'midi-trigger-once',0)
edge('midi-trigger-once',0,'midi-trigger-fanout',0)
edge('midi-trigger-fanout',1,'midi-trigger-delay',0)
edge('midi-trigger-fanout',0,'obj-113',0)
edge('midi-trigger-delay',0,'midi-trigger-reset-order',0)
edge('midi-trigger-reset-order',1,'midi-trigger-zero',0)
edge('midi-trigger-zero',0,'obj-2',0)
edge('midi-trigger-reset-order',0,'midi-trigger-once',1)
# Right-to-left: reset while onebang is closed, then rearm. Only 0->1 triggers.
ids={z['box']['id'] for z in q['boxes']}
assert len(ids)==len(q['boxes'])
assert all(l['patchline']['source'][0] in ids and l['patchline']['destination'][0] in ids for l in q['lines'])
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';h=bytearray(raw[:32]);h[28:32]=struct.pack('<I',len(payload));new=bytes(h)+payload
assert json.JSONDecoder().raw_decode(new[32:].decode())[0]==d
out=Path('work/Freqshiftdelays_m4l_trigger_prepared.amxd');out.write_bytes(new)
print('Prepared:',out,'Original SHA256:',hashlib.sha256(raw).hexdigest())
print('Change: five internal objects, pulse guard and 50-ms reset; same parameter ID/name and original downstream trigger.')
if '--apply' in sys.argv:
 backup=Path('work')/('Freqshiftdelays_m4l.before_midi_trigger_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.amxd');backup.write_bytes(raw)
 assert p.read_bytes()==raw
 p.write_bytes(new);assert p.read_bytes()==new
 print('Applied and read back. Backup:',backup.resolve())
