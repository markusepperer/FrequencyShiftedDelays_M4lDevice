from pathlib import Path
import json,copy,struct,datetime,hashlib
P=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l/Freqshiftdelays_m4l.amxd');raw=P.read_bytes();d=json.JSONDecoder().raw_decode(raw[32:].decode())[0];old=copy.deepcopy(d)
def walk(p):
 for x in p['boxes']:
  b=x['box']
  if b['maxclass']=='comment' and b.get('bgcolor',[])[:3]==[.88,.88,.88]:b['bgcolor'][3]=.5
  if 'patcher'in b:walk(b['patcher'])
def bs(p):return {x['box']['id']:x['box'] for x in p['boxes']}
walk(d['patcher']);q=bs(d['patcher'])['obj-4']['patcher'];h=bs(q)['timechange-lock']['patcher'];b=bs(h)
notes={
'doc-request':([145.,55.,310.,65.],'Alle Startwege laufen durch dieses Gate.\nEs startet offen. Bei geschlossenem Gate\nwerden weitere Trigger verworfen.\nSie werden nicht nachgeholt.'),
'doc-accept':([235.,205.,235.,78.],'t b b arbeitet von rechts nach links:\nZuerst schließt die 0 das Gate.\nDanach startet links die Sequenz.\nSo kommt auch bei mehreren schnellen\nTriggern nur ein Wechsel durch.'),
'doc-complete':([565.,55.,365.,65.],'5: Bang vom Fade-Endtimer (delay 1000).\nSeine Wartezeit ist die gewählte Fade-Dauer.\nErst Schattenzeiten senden, dann hier melden.\nDie Sperre braucht deshalb kein Fade-Zeit-Kabel.'),
'doc-release':([615.,155.,325.,65.],'6: Nach dem Fade-Ende noch 100 ms warten:\n50 ms Schattenrampe + 50 ms Sicherheit.\nDann öffnet die Nachricht 1 das Gate.\nEin neuer Trigger kann wieder passieren.'),
'doc-time':([40.,370.,875.,65.],'ABLAUF: Trigger sperrt → 650 ms Vorlauf → Fade → Schattenzeiten nachführen → 100 ms → Freigabe.\nBei 3 s Fade: Timerstart bei 0,65 s; Fade-Ende bei 3,65 s; Gate offen bei 3,75 s.\nEin längerer Fade verschiebt seine Endmeldung und damit automatisch die Freigabe.'),
'doc-midi':([40.,460.,875.,52.],'Die 50-ms-MIDI-Button-Rücksetzung arbeitet unabhängig von der Sequenzsperre.\nDer Button springt auch zurück, wenn sein Trigger während eines laufenden Wechsels verworfen wird.')}
for id,(rect,text) in notes.items():b[id].update(patching_rect=rect,text=text,linecount=text.count('\n')+1,fontsize=10.)
def strip(p):
 p=copy.deepcopy(p);p['boxes']=[x for x in p['boxes'] if x['box']['maxclass']!='comment']
 for x in p['boxes']:
  if 'patcher'in x['box']:x['box']['patcher']=strip(x['box']['patcher'])
 return p
assert strip(d['patcher'])==strip(old['patcher'])
# Verify comment bounds do not intersect any other object bounds in this subpatch.
for id in notes:
 r=b[id]['patching_rect']
 for oid,o in b.items():
  if oid==id:continue
  s=o['patching_rect'];assert not (r[0]<s[0]+s[2] and s[0]<r[0]+r[2] and r[1]<s[1]+s[3] and s[1]<r[1]+r[3]),(id,oid)
payload=json.dumps(d,ensure_ascii=False,indent=4).encode()+b'\0';head=bytearray(raw[:32]);head[28:32]=struct.pack('<I',len(payload));Path('work/soft_comments.prepared.amxd').write_bytes(bytes(head)+payload)
stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');m={'device':str(P),'backup':str(P.parent/'Backups'/('vor_Kommentartransparenz_'+stamp)),'hash':hashlib.sha256(raw).hexdigest()};Path('work/soft_comments_manifest.json').write_text(json.dumps(m));print(json.dumps(m))
