from pathlib import Path
import json,copy,datetime,sys
R=Path('/Users/macbook/Dropbox/KUG/ZKF Eigene Arbeiten/Frequencyshiftedelays_M4lDevice/FrequencyShiftedDelays_M4lDevice/MaxM4l')
ns=['MS_4Inputs_Pan_Mix.maxpat','MS_MatrixreceiveShadows.maxpat'];raw={n:(R/n).read_bytes() for n in ns};ds={n:json.loads(b) for n,b in raw.items()};old=copy.deepcopy(ds)
def bs(q):return {z['box']['id']:z['box'] for z in q['boxes']}
def evalh(q,x):
 b=bs(q);inc={}
 for e in q['lines']:
  l=e['patchline'];inc.setdefault(tuple(l['destination']),[]).append(tuple(l['source']))
 def val(id):
  if id in ['up','down','dry','mix']:return {'up':.31,'down':-.17,'dry':.23,'mix':x}[id]
  obj=b[id];t=obj.get('text','')
  def at(i):return sum(val(a) for a,p in inc.get((id,i),[]))
  if t=='clip 0. 1.':return max(0.,min(1.,at(0)))
  if t in ['pack 0. 30','line~ 1.']:return at(0)
  if t=='!-~ 1.':return 1.-at(0)
  if t=='*~':return at(0)*at(1)
  if t=='+~':return at(0)+at(1)
  if obj['maxclass']=='outlet':return at(0)
  raise AssertionError((id,t))
 return val('up-out'),val('down-out')
for n,d in ds.items():
 q=d['patcher'];h=bs(q)['shift-mix-audio']['patcher'];changed=0
 for e in h['lines']:
  l=e['patchline']
  if l['destination'] in [['up-shift',1],['down-shift',1]]:
   assert l['source']==['inverse',0];l['source']=['ramp',0];l.pop('order',None);changed+=1
  elif l['destination']==['dry-shared',1]:
   assert l['source']==['ramp',0];l['source']=['inverse',0];l.pop('order',None);changed+=1
 assert changed==3
 bs(h)['ramp']['text']='line~ 1.'
 bs(h)['mix']['comment']='Shift-Anteil 0..1: 0 ohne Shift, 1 Shift'
 bs(h)['doc']['text']='Vor Pegel/Pan: Up = x*Up + (1-x)*Delay; Down = x*Down + (1-x)*Delay. 0 % ohne Shift, 100 % Shift. Linear, 30 ms. Separater Delay-Fader unabhängig.'
 for x in [0.,.25,.5,.75,1.]:
  got=evalh(h,x);want=(x*.31+(1-x)*.23,x*(-.17)+(1-x)*.23)
  assert all(abs(a-b)<1e-12 for a,b in zip(got,want))
 assert bs(q)['delay-mix-audio']==bs(old[n]['patcher'])['delay-mix-audio']
 assert q['lines']==old[n]['patcher']['lines']
 if n==ns[0]:
  b=bs(q);v=b['shift-mix']['saved_attribute_attributes']['valueof'];v['parameter_initial']=[100.]
  b['shift-mix']['hint']='Shift-Anteil: 0 % Delay ohne Shift; 100 % Frequency Shift. Beide folgen Up/Down-Pegel und Panorama; separater Delay-Fader unabhängig.'
  b['shift-mix-left']['text']='Ohne Shift';b['shift-mix-left']['presentation_rect'][2]=70.
  b['shift-mix-right']['text']='Shift';b['shift-mix-right']['presentation_rect'][0]=119.;b['shift-mix-right']['presentation_rect'][2]=46.
  if 'presentnote'in b:b['presentnote']['text']='Shift-Mix: 0 % ohne Shift, 100 % Shift. Delay-Mix: 0 % Direkt, 100 % Delay. Up/Down-Hüllkurven und Pan bleiben wirksam.'
  for id in ['delay-mix','delay-mix-left','delay-mix-right']:assert b[id]==bs(old[n]['patcher'])[id]
 def check(q):
  b=bs(q);assert len(b)==len(q['boxes'])
  for e in q['lines']:
   a,ao=e['patchline']['source'];c,ci=e['patchline']['destination'];assert a in b and c in b and ao<b[a]['numoutlets'] and ci<b[c]['numinlets']
  for obj in b.values():
   if 'patcher'in obj:check(obj['patcher'])
 check(q)
new={n:json.dumps(d,ensure_ascii=False,indent=4).encode() for n,d in ds.items()}
out=Path('work/mix_direction_prepared');out.mkdir(exist_ok=True)
for n,b in new.items():(out/n).write_bytes(b);assert json.loads(b)==ds[n]
print('Prepared: Shift-Mix 0% unshifted, 100% shifted, default100. Delay-Mix verified 0% direct,100% delay and unchanged. Main and shadow graphs checked at five blend positions.')
if '--apply'in sys.argv:
 assert all((R/n).read_bytes()==raw[n] for n in ns)
 backup=Path('work')/('mix_direction_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
 for n,b in raw.items():(backup/n).write_bytes(b)
 for n,b in new.items():(R/n).write_bytes(b);assert (R/n).read_bytes()==b
 print('Applied; backup:',backup.resolve())
